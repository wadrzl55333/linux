package com.lzy.po;

public class TextMessage extends BaseMessage{
private String Content;

public String getContent() {
	return Content;
}
public void setContent(String content) {
	Content = content;
}
public String getMsgId() {
	return MsgId;
}
public void setMsgId(String msgId) {
	MsgId = msgId;
}
private String MsgId;
}
