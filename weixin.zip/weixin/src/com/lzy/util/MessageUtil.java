package com.lzy.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.lzy.po.Image;
import com.lzy.po.ImageMessage;
import com.lzy.po.Music;
import com.lzy.po.MusicMessage;
import com.lzy.po.News;
import com.lzy.po.NewsMessage;
import com.lzy.po.ReceiveXmlEntity;
import com.lzy.po.TextMessage;
import com.sun.org.apache.xerces.internal.xs.XSTerm;
import com.thoughtworks.xstream.XStream;

import net.sf.json.JSONObject;





public class MessageUtil {
	
	
	public static final String MESSAGE_TEXT="text";
	public static final String MESSAGE_NEWS="news";
	public static final String Message_IMAGE="image";
	public static final String Message_VOICE="voice";
	public static final String Message_VIDEO="video";
	public static final String Message_LINK="link";
	public static final String Message_LOCATION="location";
	public static final String Message_EVENT="event";
	public static final String Message_SUBSCRIBE="subscribe";
	public static final String Message_UNSUBSCRIBE="unsubscibe";
	public static final String Message_CLICK="CLICK";
	public static final String Message_VIEW="VIEW";
	public static final String Message_Scancode="scancode";
	public static final String Message_Music="music";
	public static final String Message_pic="pic_photo";
	
/**
 * xmlת��Ϊmap����
 * @param request
 * @return
 * @throws DocumentException
 * @throws IOException
 */
	public static Map<String,String> xmlToMap(HttpServletRequest request) throws DocumentException, IOException{
		Map<String, String> map=new HashMap<String,String>();
		SAXReader reader=new SAXReader();
		
		InputStream ins=request.getInputStream();
		org.dom4j.Document doc=reader.read(ins);
		
		Element root=doc.getRootElement();
		List<Element> list=root.elements();
		for(Element e:list){
		map.put(e.getName(), e.getText());
		}
		ins.close();
		return map;
	}
	/**
	* ��ͼ���������Ϣ����ת��Ϊxml�ķ���(�ı�)
	 * @param textmessage
	 * @return
	 */
	public static String TulingTextMessageToXml(ReceiveXmlEntity receiveXmlEntity)
	{
	XStream xStream=new XStream();
	xStream.alias("xml", receiveXmlEntity.getClass());
	return xStream.toXML(receiveXmlEntity);
	}
	
	/**
	 * ͼ������˷�����Ϣ
	 * @param content
	 * @return
	 * @throws Exception
	 */
	public static String tuLingjiqiren(String toUserName,String fromUserName,String content) throws Exception
	{
	String message=null;
	String APIKEY="9a518d9975e541c9aa19d15dd1d7fa2b";
	String INFO=URLEncoder.encode(content,"UTF-8");
	String getURL="http://www.tuling123.com/openapi/api?key=" + APIKEY + "&info=" + INFO;
	URL getUrl=new URL(getURL);
	HttpURLConnection connection=(HttpURLConnection)getUrl.openConnection();
	connection.connect();

	//ȡ��������,��ʹ��Reader��ȡ
	BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
	StringBuffer sBuffer=new StringBuffer();
	String line="";
	while((line=reader.readLine())!=null)
	{
	sBuffer.append(line);
	}
	String mess=sBuffer.toString();

	//����ͼ�������ݣ���ȡ��������
	JSONObject json= JSONObject.fromObject(mess);
	mess = json.getString("text");
	reader.close();
	//�Ͽ�����
	connection.disconnect();
	System.out.println(mess);

	ReceiveXmlEntity xmlEntity=new ReceiveXmlEntity();
	xmlEntity.setFromUserName(toUserName);
	xmlEntity.setToUserName(fromUserName);
	xmlEntity.setMsgType(MESSAGE_TEXT);
	xmlEntity.setCreateTime(new Date().getTime());
	xmlEntity.setContent(mess);
	xmlEntity.setMsgId(null);
	message=TulingTextMessageToXml(xmlEntity);
	return message;
	//return sBuffer+"";
	}
	/**
	 * ���ı���Ϣ����ת��Ϊxml
	 * @param textMessage
	 * @return
	 */
	public static String textMessageToXml(TextMessage textMessage){
		XStream xstream=new XStream();
		xstream.alias("xml",textMessage.getClass());
		return xstream.toXML(textMessage);
	}
	
	public static String initText(String toUserName,String fromUserName,String content){
		TextMessage text=new TextMessage();
		text.setFromUserName(toUserName);
		text.setToUserName(fromUserName);
		text.setMsgType(MessageUtil.MESSAGE_TEXT);
		text.setCreateTime(new Date().getTime());
		text.setContent(content);
		return textMessageToXml(text);
	}
	/**
	 * ���˵�
	 * @return
	 */
	public static String menuText(){
		StringBuffer sb=new StringBuffer();
		sb.append("��ӭ���Ĺ�ע���밴�ղ˵���ʾ���в�����\n\n");
		sb.append("1.�츮��ʳ���޹��ܽ���\n");
		sb.append("2.��ȡ�ù��ںŶ�ά��\n\n");
		sb.append("�ظ��������˲˵���");
		return sb.toString();
	}
	public static String firstMenu(){
		StringBuffer sb=new StringBuffer();
		sb.append("�ù��ں��ṩһЩ�Ĵ�����ɫ��ʳ�Ƽ�����ʳ�����а��˺���ʳ��ͼƬ���̳Ǻ�һЩ������С���ܣ���鿴����Ԥ������ȡ��ǰλ��");
		
		return sb.toString();
	}
	public static String weatherText(){
		StringBuffer sb=new StringBuffer();
		sb.append("---------");
		sb.append("�밴��ʽ������Ҫ��ѯ�����ĳ��У����������У���");
		sb.append("---------");
		return sb.toString();
	}
	public static String secondMenu(){
		StringBuffer sb=new StringBuffer();
		sb.append("�����Ĵ��ɶ��е���ɫ��ʳ������С�ԣ����ķ��׵�...");
		
		return sb.toString();
	}
	/**
	 * ͼ����ϢתΪXML
	 * @param newsMessage
	 * @return
	 */
	public static String newsMessageToXml(NewsMessage newsMessage){
		XStream xstream=new XStream();
		xstream.alias("xml",newsMessage.getClass());
		xstream.alias("item",new News().getClass());
		return xstream.toXML(newsMessage);
	}
	
	/**
	 * ͼƬ��ϢתΪxml
	 */
	public static String imageMessageToXml(ImageMessage imageMessage){
		XStream xstream=new XStream();
		xstream.alias("xml",imageMessage.getClass());
		return xstream.toXML(imageMessage);
	}
	
	/**
	 * 
	 * ������Ϣת��Ϊxml
	 *
	 */
	public static String musicMessageToXml(MusicMessage musicMessage){
		XStream xstream=new XStream();
		xstream.alias("xml",musicMessage.getClass());
		return xstream.toXML(musicMessage);
	}
	/**
	 * ͼ����Ϣ����װ
	 * @param toUserName
	 * @param fromUserName
	 * @return
	 */
	public static String initNewsMessage(String toUserName,String fromUserName){
		String message=null;
		List<News> newList=new ArrayList<News>();
		NewsMessage newsMessage=new NewsMessage();
		
		News news=new News();
		news.setTitle("�츮��ʳ����");
		news.setDescription("�Ĵ��������۾������ã�����ζ���Ľ������Ĵ���ʳ���Ĵ�С�Ա�ض��ǣ�ÿһ�����Ĵ������Ѷ����Ϊ�����Ի���������һ��ζ����Ծ��!");
		news.setPicUrl("http://60.205.221.212/weixin/image/erweima.png");
		news.setUrl("http://60.205.221.212/weixin/image/erweima.png");
		
		newList.add(news);
		newsMessage.setToUserName(fromUserName);
		newsMessage.setFromUserName(toUserName);
		newsMessage.setCreateTime(new Date().getTime());
		newsMessage.setMsgType(MESSAGE_NEWS);
		newsMessage.setArticles(newList);
		newsMessage.setArticleCount(newList.size());
		message=newsMessageToXml(newsMessage);
		
		return message;
	}
	/**
	 * ͼƬ��Ϣ����װ
	 * @param toUserName
	 * @param fromUserName
	 * @return
	 */
	public static String initImageMessage(String toUserName,String fromUserName){
		String message=null;
		Image image=new Image();
		image.setMediaId("ZzixCWnLJtI33YAkJWkEgsM4lT6_3guUNf4Sz522t60yqwBZeg00S81mhHy3RJs7");
		ImageMessage imageMessage=new ImageMessage();
		imageMessage.setFromUserName(toUserName);
		imageMessage.setToUserName(fromUserName);
		imageMessage.setMsgType(Message_IMAGE);
		imageMessage.setCreateTime(new Date().getTime());
		imageMessage.setImage(image);
		message=imageMessageToXml(imageMessage);
		return message;
	}
	/**
	 * ������Ϣ����װ
	 * 
	 */
//	public static String initmusicImageMessage(String toUserName,String fromUserName){
//		String message=null;
//		Music music=new Music();
//		music.setThumbMediaId("YLDaW7rR5wa3l5tS09ihW3XbJtzmp-0_F74RY9JEbO3dy3TvIYEUynxacET_XTeA");
//		
//		music.setTitle("���������");
//		music.setDescription("����Ѹ����");
//		music.setMusicUrl("http://734172767.tunnel.2bdata.com/weixin/resource/���������.mp3");
//		music.setHQMusicUrl("http://734172767.tunnel.2bdata.com/weixin/resource/���������.mp3");
//		
//		MusicMessage musicMessage=new MusicMessage();
//		musicMessage.setFromUserName(toUserName);
//		musicMessage.setToUserName(fromUserName);
//		musicMessage.setMsgType(Message_Music);
//		musicMessage.setCreateTime(new Date().getTime());
//		musicMessage.setMusic(music);
//		message=musicMessageToXml(musicMessage);
//		return message;
//	}
}
