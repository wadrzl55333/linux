package com.lzy.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dom4j.DocumentException;

import com.lzy.po.TextMessage;
import com.lzy.po.WeatherService;
import com.lzy.util.CheckUtil;
import com.lzy.util.HttpRequestUtil;
import com.lzy.util.MessageUtil;

/**
 * Servlet implementation class WeixinServlets
 */
@WebServlet("/WeixinServlets")
public class WeixinServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WeixinServlets() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String signature=request.getParameter("signature");
		String timestamp=request.getParameter("timestamp");
		String nonce=request.getParameter("nonce");
		String echostr=request.getParameter("echostr");
		
		PrintWriter out=response.getWriter();
		if(CheckUtil.checkSignature(signature, timestamp, nonce)){
			out.print(echostr);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out=response.getWriter();
		try{
			Map<String,String> map=MessageUtil.xmlToMap(request);
			String fromUserName=map.get("FromUserName");
			String toUserName=map.get("ToUserName");
			String msgType=map.get("MsgType");
			String content=map.get("Content");
			
			String message=null;
			if(MessageUtil.MESSAGE_TEXT.equals(msgType)){
				if("1".equals(content)){
					message=MessageUtil.initText(toUserName, fromUserName, MessageUtil.firstMenu());
				}else if("2".equals(content)){
					message=MessageUtil.initImageMessage(toUserName, fromUserName);
				}
//					else if("3".equals(content)){
//					message=MessageUtil.initImageMessage(toUserName, fromUserName);
//				}else if("4".equals(content)){
//					//message=MessageUtil.initmusicImageMessage(toUserName, fromUserName);
//				}
					else if((content).contains("����:")||(content).contains("������")){
						String contents=content.substring(3, content.length());
					message=MessageUtil.initText(toUserName, fromUserName, WeatherService.getWeatherInfo(contents ));
				}
//				else{
//					try {
//						message=MessageUtil.tuLingjiqiren(toUserName, fromUserName, content);
//					} catch (Exception e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//				}
				
			}else if(MessageUtil.Message_EVENT.equals(msgType)){
				Boolean bl=false;
				String eventType=map.get("Event");
				String eventKeys=map.get("EventKey").trim();
				System.out.println(eventType+" "+eventKeys);

				if(MessageUtil.Message_SUBSCRIBE.equals(eventType)){
					message=MessageUtil.initText(toUserName, fromUserName, MessageUtil.menuText());
					
				}else if(MessageUtil.Message_VIEW.equals(eventType)){
					String url=map.get("EventKey");
					message=MessageUtil.initText(toUserName, fromUserName, url);
				}else if(MessageUtil.Message_Scancode.equals(eventType)){
					String result=map.get("ScanResult");
					message=MessageUtil.initText(toUserName, fromUserName, result);
				}else if(MessageUtil.Message_pic.equals(eventType)){
					String list=map.get("PicList");
					message=MessageUtil.initText(toUserName, fromUserName, list);
				}
				else if(MessageUtil.Message_CLICK.equals(eventType)&&eventKeys.equals("41")){
					message=MessageUtil.initText(toUserName, fromUserName,MessageUtil.weatherText());	
//					message=MessageUtil.initText(toUserName, fromUserName, MessageUtil.menuText());
					}
                else if(MessageUtil.Message_CLICK.equals(eventType)&&eventKeys.equals("72")){
					
                	message=MessageUtil.initText(toUserName, fromUserName, MessageUtil.menuText());
					}
			}else if(MessageUtil.Message_LOCATION.equals(msgType)){
				String label=map.get("Label");
				message=MessageUtil.initText(toUserName, fromUserName,label);
			}
			
			out.print(message);
		}catch(DocumentException e){
			e.printStackTrace();
		}finally {
			out.close();
		}
	}

}
