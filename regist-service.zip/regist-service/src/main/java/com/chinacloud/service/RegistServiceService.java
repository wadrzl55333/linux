/**
 * 
 */
package com.chinacloud.service;

import static org.springframework.http.HttpMethod.DELETE;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.chinacloud.common.ResponseObject;
import com.chinacloud.dto.ApiServiceDto;
import com.chinacloud.dto.BusinessInformationDto;
import com.chinacloud.dto.CorsConfigurationDto;
import com.chinacloud.dto.FourthOverviewDto;
import com.chinacloud.dto.SecondOverviewDto;
import com.chinacloud.dto.ServiceOverviewDto;
import com.chinacloud.dto.ThirdOverviewDto;
import com.chinacloud.resource.RegistServiceResource;
import static com.chinacloud.configuration.ConfigurationProvider1.HEADER;

@Service
public class RegistServiceService {

	private RestTemplate restTemplate = new RestTemplate();

	/**
	 * 注册服务
	 */
	public ResponseObject<Map<String, Object>> RegistServiceOverviw() {
		ParameterizedTypeReference<ResponseObject<Map<String, Object>>> responseType = new ParameterizedTypeReference<ResponseObject<Map<String, Object>>>() {
		};
		String result = "";
		ServiceOverviewDto serviceOverviewDto = new ServiceOverviewDto();
		serviceOverviewDto.setServiceId(null);
		serviceOverviewDto.setServiceName("服务名称test111");
		serviceOverviewDto.setServiceCategoryId("7894326e-fdb7-4de5-9f3c-a75f8ac9aca8_1483947960000");
		serviceOverviewDto.setServiceDescription("服务介绍test");
		serviceOverviewDto.setCreatorId("bfc27112-fedf-413c-9946-4a45319c1a92");
		serviceOverviewDto.setProvider("shengting-admin@test.com");
		serviceOverviewDto.setServiceType(1);
		serviceOverviewDto.setApiType("REST");
		serviceOverviewDto.setProjectId("04cf8dff-0f48-4493-877b-4a0c224ec3f9");

		HttpHeaders headers = new HttpHeaders();
		headers.add("X-Auth-Token", HEADER);
		HttpEntity httpEntity = new HttpEntity(serviceOverviewDto, headers);
		ResponseEntity<ResponseObject<Map<String, Object>>> response = restTemplate
				.exchange("http://172.16.80.90/business/service/saveServiceOverview", POST, httpEntity, responseType);
		return response.getBody();
	}

	/**
	 * 通过RegistServiceService传的id来进行日志添加
	 * 
	 * @param id
	 */
	public ResponseObject<Map<String, Object>> RegistServiceOverviw2(String id) {
		ParameterizedTypeReference<ResponseObject<Map<String, Object>>> responseType = new ParameterizedTypeReference<ResponseObject<Map<String, Object>>>() {
		};
		String result = "";
		SecondOverviewDto serviceOverviewDto = new SecondOverviewDto();
		serviceOverviewDto.setContext("/111111123123");
		serviceOverviewDto.setIsDefaultVersion(false);
		List<String> a = new ArrayList<String>();
		a.add("http");
		a.add("https");
		List<String> b = new ArrayList<String>();
		b.add("Unlimited");
		serviceOverviewDto.setTransport(a);
		serviceOverviewDto.setTiers(b);
		serviceOverviewDto.setEndpointConfig(
				"{\"production_endpoints\":{\"url\":null,\"config\":null},\"sandbox_endpoints\":{\"url\":null,\"config\":null},\"endpoint_type\":\"http\"}");
		serviceOverviewDto.setName("addd111123");
		serviceOverviewDto.setVersion("v1");
		serviceOverviewDto.setApiDefinition(
				"{\"swagger\":\"2.0\",\"paths\":{\"/v1\":{\"get\":{\"responses\":{\"200\":{\"description\":\"\"}},\"xAuthType\":\"Application & Application User\",\"description\":\"\",\"produces\":[\"application/json\"],\"consumes\":[\"application/json\"],\"summary\":\"\",\"inputname\":\"\",\"parameterDisplay\":false,\"parameters\":[]}}}}");

		HttpHeaders headers = new HttpHeaders();
		headers.add("X-Auth-Token", HEADER);
		HttpEntity httpEntity = new HttpEntity(serviceOverviewDto, headers);
		String url = "http://172.16.80.90/business/apiservices/{keyWord}/apis/get";

		url = url.replace("{keyWord}", id);

		ResponseEntity<ResponseObject<Map<String, Object>>> response = restTemplate.exchange(url, POST, httpEntity,
				responseType);
		return response.getBody();
	}

	/**
	 * 不知
	 * 
	 * @param id
	 */
	public ResponseObject<Map<String, Object>> RegistServiceOverviw3(String id) {
		ParameterizedTypeReference<ResponseObject<Map<String, Object>>> responseType = new ParameterizedTypeReference<ResponseObject<Map<String, Object>>>() {
		};
		String result = "";
		ThirdOverviewDto serviceOverviewDto = new ThirdOverviewDto();
		serviceOverviewDto.setServiceId(id);
		serviceOverviewDto.setNotificationUrl(
				"http://172.16.80.92:8092/apim-service-broker/v2/event/24e80656-70d3-4122-a8df-03cb2b169aa2/v1?url={eventUrl}");
		serviceOverviewDto.setCustomVersion("");
		List<String> a = new ArrayList<String>();
		serviceOverviewDto.setCustomEvents(a);
		HttpHeaders headers = new HttpHeaders();
		headers.add("X-Auth-Token", HEADER);
		HttpEntity httpEntity = new HttpEntity(serviceOverviewDto, headers);
		ResponseEntity<ResponseObject<Map<String, Object>>> response = restTemplate
				.exchange("http://172.16.80.90/business/service/saveServiceKey", POST, httpEntity, responseType);
		return response.getBody();
	}

	/**
	 * 通过RegistServiceService传id
	 * 
	 * @param id
	 * @param id2
	 */
	public ResponseObject<ApiServiceDto> RegistServiceOverviw4(String serviceid, String id) {
		ParameterizedTypeReference<ResponseObject<ApiServiceDto>> responseType = new ParameterizedTypeReference<ResponseObject<ApiServiceDto>>() {
		};
		String result = "";
		ApiServiceDto serviceOverviewDto = new ApiServiceDto();
		serviceOverviewDto.setId(id);
		serviceOverviewDto.setName("addd111123");
		serviceOverviewDto.setContext("/111111123123");
		serviceOverviewDto.setVersion("v1");
		serviceOverviewDto.setProvider("admin");
		serviceOverviewDto.setApiDefinition(
				"{\"swagger\":\"2.0\",\"paths\":{\"/v1\":{\"get\":{\"responses\":{\"200\":{\"description\":\"\"}},\"xAuthType\":\"Application & Application User\",\"description\":\"\",\"produces\":[\"application/json\"],\"consumes\":[\"application/json\"],\"summary\":\"\",\"inputname\":\"\",\"parameterDisplay\":false,\"parameters\":[]}}}}");
		serviceOverviewDto.setStatus("CREATED");
		serviceOverviewDto.setCacheTimeout(0);
		List<String> Transport = new ArrayList<String>();
		Transport.add("http");
		Transport.add("https");
		List<String> Tiers = new ArrayList<String>();
		Tiers.add("Unlimited");
		serviceOverviewDto.setTransport(Transport);
		serviceOverviewDto.setTiers(Tiers);
		List<String> Tags = new ArrayList<String>();
		Tags.add("default");
		serviceOverviewDto.setTags(Tags);
		serviceOverviewDto.setVisibility("PUBLIC");
		serviceOverviewDto.setEndpointConfig(
				"{\"production_endpoints\":{\"url\":\"http://www.baidu.com\",\"config\":null},\"sandbox_endpoints\":{\"url\":\"http://www.baidu.com\",\"config\":null},\"endpoint_type\":\"http\"}");
		serviceOverviewDto.setGatewayEnvironments("Production and Sandbox");
		BusinessInformationDto businessinformationdto = new BusinessInformationDto();
		/*
		 * businessinformationdto.setBusinessOwner(null);
		 * businessinformationdto.setBusinessOwnerEmail(null);
		 * businessinformationdto.setTechnicalOwner(null);
		 * businessinformationdto.setTechnicalOwnerEmail(null);
		 */
		serviceOverviewDto.setBusinessInformation(businessinformationdto);
		CorsConfigurationDto configurationdto = new CorsConfigurationDto();
		List<String> conf = new ArrayList<String>();
		conf.add("*");
		configurationdto.setAccessControlAllowOrigins(conf);
		configurationdto.setAccessControlAllowCredentials(false);
		configurationdto.setCorsConfigurationEnabled(true);
		serviceOverviewDto.setIsDefaultVersion(false);
		List<String> accesscontrolallowheaders = new ArrayList<String>();
		accesscontrolallowheaders.add("authorization");
		accesscontrolallowheaders.add("Access-Control-Allow-Origin");
		accesscontrolallowheaders.add("Content-Type");
		accesscontrolallowheaders.add("SOAPAction");
		configurationdto.setAccessControlAllowHeaders(accesscontrolallowheaders);
		List<String> accesscontrolallowmethods = new ArrayList<String>();
		accesscontrolallowmethods.add("GET");
		accesscontrolallowmethods.add("PUT");
		accesscontrolallowmethods.add("POST");
		accesscontrolallowmethods.add("DELETE");
		accesscontrolallowmethods.add("PATCH");
		accesscontrolallowmethods.add("OPTIONS");
		configurationdto.setAccessControlAllowMethods(accesscontrolallowmethods);

		HttpHeaders headers = new HttpHeaders();
		headers.add("X-Auth-Token", HEADER);
		HttpEntity httpEntity = new HttpEntity(serviceOverviewDto, headers);
		String url = "http://172.16.80.90/business/apiservices/{0}/apis/{1}/get";

		url = url.replace("{0}", serviceid);
		url = url.replace("{1}", id);
		ResponseEntity<ResponseObject<ApiServiceDto>> response = restTemplate.exchange(url, PUT, httpEntity,
				responseType);
		return response.getBody();
	}
}
