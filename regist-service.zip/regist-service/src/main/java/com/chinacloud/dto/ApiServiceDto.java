package com.chinacloud.dto;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * api类服务表单对象
 * @author Administrator
 *
 */
public class ApiServiceDto {
	
	private String id;
	
	//Required
	@NotEmpty
	private String name;
	
	private String description;
	
	@NotEmpty
	private String context;
	
	@NotEmpty
	private String version;
	
	private String provider;
	
	private String apiDefinition;
	
	private String wsdlUri;
	
	private String status;
	
	private String responseCaching;
	
	private int cacheTimeout;
	
	private String destinationStatsEnabled;
	
	//required
	private boolean isIsDefaultVersion = false;
	
	//required
	private List<String> transport;
	
	private List<String> tags;
	
	//required
	private List<String> tiers;
	
	private MaxTpsDto maxTps;
	
	private String thumbnailUri;
	
	//required
	private String visibility = "PUBLIC";
	
	private List<String> visibleRoles;
	
	private List<String> visibleTenants;
	
	private String endpointConfig;
	
	//required
	private EndpointSecurityDto endpointSecurity;
	
	private String gatewayEnvironments;
	
	private List<String> sequences;
	
	private String subscriptionAvailability;
	
	private BusinessInformationDto businessInformation;
	
	private List<String> subscriptionAvailableTenants;
	
	private CorsConfigurationDto corsConfiguration;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getApiDefinition() {
		return apiDefinition;
	}

	public void setApiDefinition(String apiDefinition) {
		this.apiDefinition = apiDefinition;
	}

	public String getWsdlUri() {
		return wsdlUri;
	}

	public void setWsdlUri(String wsdlUri) {
		this.wsdlUri = wsdlUri;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getResponseCaching() {
		return responseCaching;
	}

	public void setResponseCaching(String responseCaching) {
		this.responseCaching = responseCaching;
	}

	public int getCacheTimeout() {
		return cacheTimeout;
	}

	public void setCacheTimeout(int cacheTimeout) {
		this.cacheTimeout = cacheTimeout;
	}

	public String getDestinationStatsEnabled() {
		return destinationStatsEnabled;
	}

	public void setDestinationStatsEnabled(String destinationStatsEnabled) {
		this.destinationStatsEnabled = destinationStatsEnabled;
	}

	public boolean isIsDefaultVersion() {
		return isIsDefaultVersion;
	}

	public void setIsDefaultVersion(boolean isIsDefaultVersion) {
		this.isIsDefaultVersion = isIsDefaultVersion;
	}

	public List<String> getTransport() {
		return transport;
	}

	public void setTransport(List<String> transport) {
		this.transport = transport;
	}

	public List<String> getTags() {
		return tags;
	}

	public void setTags(List<String> tags) {
		this.tags = tags;
	}

	public List<String> getTiers() {
		return tiers;
	}

	public void setTiers(List<String> tiers) {
		this.tiers = tiers;
	}

	public MaxTpsDto getMaxTps() {
		return maxTps;
	}

	public void setMaxTps(MaxTpsDto maxTps) {
		this.maxTps = maxTps;
	}

	public String getThumbnailUri() {
		return thumbnailUri;
	}

	public void setThumbnailUri(String thumbnailUri) {
		this.thumbnailUri = thumbnailUri;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public List<String> getVisibleRoles() {
		return visibleRoles;
	}

	public void setVisibleRoles(List<String> visibleRoles) {
		this.visibleRoles = visibleRoles;
	}

	public List<String> getVisibleTenants() {
		return visibleTenants;
	}

	public void setVisibleTenants(List<String> visibleTenants) {
		this.visibleTenants = visibleTenants;
	}

	public String getEndpointConfig() {
		return endpointConfig;
	}

	public void setEndpointConfig(String endpointConfig) {
		this.endpointConfig = endpointConfig;
	}

	public EndpointSecurityDto getEndpointSecurity() {
		return endpointSecurity;
	}

	public void setEndpointSecurity(EndpointSecurityDto endpointSecurity) {
		this.endpointSecurity = endpointSecurity;
	}

	public String getGatewayEnvironments() {
		return gatewayEnvironments;
	}

	public void setGatewayEnvironments(String gatewayEnvironments) {
		this.gatewayEnvironments = gatewayEnvironments;
	}

	public List<String> getSequences() {
		return sequences;
	}

	public void setSequences(List<String> sequences) {
		this.sequences = sequences;
	}

	public String getSubscriptionAvailability() {
		return subscriptionAvailability;
	}

	public void setSubscriptionAvailability(String subscriptionAvailability) {
		this.subscriptionAvailability = subscriptionAvailability;
	}

	public BusinessInformationDto getBusinessInformation() {
		return businessInformation;
	}

	public void setBusinessInformation(BusinessInformationDto businessInformation) {
		this.businessInformation = businessInformation;
	}

	public List<String> getSubscriptionAvailableTenants() {
		return subscriptionAvailableTenants;
	}

	public void setSubscriptionAvailableTenants(List<String> subscriptionAvailableTenants) {
		this.subscriptionAvailableTenants = subscriptionAvailableTenants;
	}

	public CorsConfigurationDto getCorsConfiguration() {
		return corsConfiguration;
	}

	public void setCorsConfiguration(CorsConfigurationDto corsConfiguration) {
		this.corsConfiguration = corsConfiguration;
	}

}
