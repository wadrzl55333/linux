/**
 * 
 */
package com.chinacloud.dto;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * @author zhangmenghao
 *
 */
public class ServiceOverviewDto {

	// 服务ID
	private String serviceId;

	// 服务名称
	@Size(max = 40)
	private String serviceName;

	// 服务种类
	@NotNull
	private String serviceCategoryId;

	// 服务描述
	@Size(max = 2048)
	private String serviceDescription;

	// 服务图标
	private String logoImgResult;

	// 服务图片
	private String overviewImgResult;

	// 页面操作人
	private String creatorId;

	// 服务提供者
	private String provider;

	// 信息完整度
	private String infoIntegrity;

	private Date overviewVersion;

	private Date serviceCategoryLastModified;

	private int serviceType;

	private String apiType;

	/**
	 * 所属项目id
	 */
	@NotNull
	private String projectId;

	// 应用id
	private Integer appId;

	// 应用名称
	private String appName;

	// 项目名称
	private String projectName;

	private String apiServiceId;

	public Date getOverviewVersion() {
		return overviewVersion;
	}

	public void setOverviewVersion(Date overviewVersion) {
		this.overviewVersion = overviewVersion;
	}

	public Date getServiceCategoryLastModified() {
		return serviceCategoryLastModified;
	}

	public void setServiceCategoryLastModified(Date serviceCategoryLastModified) {
		this.serviceCategoryLastModified = serviceCategoryLastModified;
	}

	public String getInfoIntegrity() {
		return infoIntegrity;
	}

	public void setInfoIntegrity(String infoIntegrity) {
		this.infoIntegrity = infoIntegrity;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getLogoImgResult() {
		return logoImgResult;
	}

	public void setLogoImgResult(String logoImgResult) {
		this.logoImgResult = logoImgResult;
	}

	public String getOverviewImgResult() {
		return overviewImgResult;
	}

	public void setOverviewImgResult(String overviewImgResult) {
		this.overviewImgResult = overviewImgResult;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getServiceCategoryId() {
		return serviceCategoryId;
	}

	public void setServiceCategoryId(String serviceCategoryId) {
		this.serviceCategoryId = serviceCategoryId;
	}

	public String getServiceDescription() {
		return serviceDescription;
	}

	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	/**
	 * 取得projectId
	 * 
	 * @return the projectId
	 */
	public String getProjectId() {
		return projectId;
	}

	/**
	 * 设置projectId
	 * 
	 * @param projectId
	 *            the projectId to set
	 */
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	/**
	 * 取得appId
	 * 
	 * @return the appId
	 */
	public Integer getAppId() {
		return appId;
	}

	/**
	 * 设置appId
	 * 
	 * @param appId
	 *            the appId to set
	 */
	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	/**
	 * 取得appName
	 * 
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}

	/**
	 * 设置appName
	 * 
	 * @param appName
	 *            the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}

	/**
	 * 取得projectName
	 * 
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * 设置projectName
	 * 
	 * @param projectName
	 *            the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public int getServiceType() {
		return serviceType;
	}

	public void setServiceType(int serviceType) {
		this.serviceType = serviceType;
	}

	public String getApiServiceId() {
		return apiServiceId;
	}

	public void setApiServiceId(String apiServiceId) {
		this.apiServiceId = apiServiceId;
	}

	public String getApiType() {
		return apiType;
	}

	public void setApiType(String apiType) {
		this.apiType = apiType;
	}
}
