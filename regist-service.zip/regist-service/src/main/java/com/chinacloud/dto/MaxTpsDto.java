package com.chinacloud.dto;

public class MaxTpsDto {
	
	private long sandbox;
	
	private long production;
	
	public long getSandbox() {
		return sandbox;
	}
	public void setSandbox(long sandbox) {
		this.sandbox = sandbox;
	}
	public long getProduction() {
		return production;
	}
	public void setProduction(long production) {
		this.production = production;
	}
}
