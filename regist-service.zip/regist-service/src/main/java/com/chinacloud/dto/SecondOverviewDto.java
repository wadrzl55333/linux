package com.chinacloud.dto;

import java.util.List;

public class SecondOverviewDto {

	private String context;

	private boolean isIsDefaultVersion;

	public boolean isIsDefaultVersion() {
		return isIsDefaultVersion;
	}

	public void setIsDefaultVersion(boolean isIsDefaultVersion) {
		this.isIsDefaultVersion = isIsDefaultVersion;
	}

	private List<String> transport;

	private List<String> tiers;

	private String endpointConfig;

	private String name;

	private String version;

	private String apiDefinition;

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public List<String> getTransport() {
		return transport;
	}

	public void setTransport(List<String> transport) {
		this.transport = transport;
	}

	public List<String> getTiers() {
		return tiers;
	}

	public void setTiers(List<String> tiers) {
		this.tiers = tiers;
	}

	public String getEndpointConfig() {
		return endpointConfig;
	}

	public void setEndpointConfig(String endpointConfig) {
		this.endpointConfig = endpointConfig;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getApiDefinition() {
		return apiDefinition;
	}

	public void setApiDefinition(String apiDefinition) {
		this.apiDefinition = apiDefinition;
	}

}
