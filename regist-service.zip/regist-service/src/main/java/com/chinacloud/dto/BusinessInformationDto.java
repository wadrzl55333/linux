package com.chinacloud.dto;

public class BusinessInformationDto {

	private String businessOwnerEmail;
	
    private String technicalOwnerEmail;
    
    private String technicalOwner;
    
    private String businessOwner;

	public String getBusinessOwnerEmail() {
		return businessOwnerEmail;
	}

	public void setBusinessOwnerEmail(String businessOwnerEmail) {
		this.businessOwnerEmail = businessOwnerEmail;
	}

	public String getTechnicalOwnerEmail() {
		return technicalOwnerEmail;
	}

	public void setTechnicalOwnerEmail(String technicalOwnerEmail) {
		this.technicalOwnerEmail = technicalOwnerEmail;
	}

	public String getTechnicalOwner() {
		return technicalOwner;
	}

	public void setTechnicalOwner(String technicalOwner) {
		this.technicalOwner = technicalOwner;
	}

	public String getBusinessOwner() {
		return businessOwner;
	}

	public void setBusinessOwner(String businessOwner) {
		this.businessOwner = businessOwner;
	}
    
	
}
