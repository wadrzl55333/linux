package com.chinacloud.dto;

import java.util.List;

public class FourthOverviewDto {

	private String id;

	private String name;

	private String description;

	private String context;

	private String version;

	private String provider;

	private String apiDefinition;

	private String wsdUri;

	private String Status;

	private String responseCaching;

	private int catchTimeout;

	private String destinationStatsEnabled;

	private List<String> transport;

	private List<String> tags;

	private List<String> tiers;

	private String mapTps;

	private String thumbnailUri;

	private String visibility;

	private List<String> visibleRoles;

	private List<String> visibleTenants;

	private String endpointConfig;

	private String endpointSecurity;

	private String gatewayEnvironments;

	private List<String> sequences;

	private String subscriptionAvailability;

	private BusinessInformationDto businessInformation;

	private String subscriptionAvailableTenants;

	private CorsConfigurationDto corsConfiguration;

	private boolean accessControlAllowCredentials;

	private boolean corsConfigurationEnabled;

	private List<String> accessControlAllowHeaders;

	private List<String> accessControlAllowMethods;

	private boolean isIsDefaultVersion;

	public boolean isIsDefaultVersion() {
		return isIsDefaultVersion;
	}

	public void setIsDefaultVersion(boolean isIsDefaultVersion) {
		this.isIsDefaultVersion = isIsDefaultVersion;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getApiDefinition() {
		return apiDefinition;
	}

	public void setApiDefinition(String apiDefinition) {
		this.apiDefinition = apiDefinition;
	}

	public String getWsdUri() {
		return wsdUri;
	}

	public void setWsdUri(String wsdUri) {
		this.wsdUri = wsdUri;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getResponseCaching() {
		return responseCaching;
	}

	public void setResponseCaching(String responseCaching) {
		this.responseCaching = responseCaching;
	}

	public int getCatchTimeout() {
		return catchTimeout;
	}

	public void setCatchTimeout(int catchTimeout) {
		this.catchTimeout = catchTimeout;
	}

	public String getDestinationStatsEnabled() {
		return destinationStatsEnabled;
	}

	public void setDestinationStatsEnabled(String destinationStatsEnabled) {
		this.destinationStatsEnabled = destinationStatsEnabled;
	}

	public List<String> getTransport() {
		return transport;
	}

	public void setTransport(List<String> transport) {
		this.transport = transport;
	}

	public List<String> getTags() {
		return tags;
	}

	public void setTags(List<String> tags) {
		this.tags = tags;
	}

	public List<String> getTiers() {
		return tiers;
	}

	public void setTiers(List<String> tiers) {
		this.tiers = tiers;
	}

	public String getMapTps() {
		return mapTps;
	}

	public void setMapTps(String mapTps) {
		this.mapTps = mapTps;
	}

	public String getThumbnailUri() {
		return thumbnailUri;
	}

	public void setThumbnailUri(String thumbnailUri) {
		this.thumbnailUri = thumbnailUri;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public List<String> getVisibleRoles() {
		return visibleRoles;
	}

	public void setVisibleRoles(List<String> visibleRoles) {
		this.visibleRoles = visibleRoles;
	}

	public List<String> getVisibleTenants() {
		return visibleTenants;
	}

	public void setVisibleTenants(List<String> visibleTenants) {
		this.visibleTenants = visibleTenants;
	}

	public String getEndpointConfig() {
		return endpointConfig;
	}

	public void setEndpointConfig(String endpointConfig) {
		this.endpointConfig = endpointConfig;
	}

	public String getEndpointSecurity() {
		return endpointSecurity;
	}

	public void setEndpointSecurity(String endpointSecurity) {
		this.endpointSecurity = endpointSecurity;
	}

	public String getGatewayEnvironments() {
		return gatewayEnvironments;
	}

	public void setGatewayEnvironments(String gatewayEnvironments) {
		this.gatewayEnvironments = gatewayEnvironments;
	}

	public List<String> getSequences() {
		return sequences;
	}

	public void setSequences(List<String> sequences) {
		this.sequences = sequences;
	}

	public String getSubscriptionAvailability() {
		return subscriptionAvailability;
	}

	public void setSubscriptionAvailability(String subscriptionAvailability) {
		this.subscriptionAvailability = subscriptionAvailability;
	}

	public BusinessInformationDto getBusinessInformation() {
		return businessInformation;
	}

	public void setBusinessInformation(BusinessInformationDto businessInformation) {
		this.businessInformation = businessInformation;
	}

	public String getSubscriptionAvailableTenants() {
		return subscriptionAvailableTenants;
	}

	public void setSubscriptionAvailableTenants(String subscriptionAvailableTenants) {
		this.subscriptionAvailableTenants = subscriptionAvailableTenants;
	}

	public CorsConfigurationDto getCorsConfiguration() {
		return corsConfiguration;
	}

	public void setCorsConfiguration(CorsConfigurationDto corsConfiguration) {
		this.corsConfiguration = corsConfiguration;
	}

	public boolean isAccessControlAllowCredentials() {
		return accessControlAllowCredentials;
	}

	public void setAccessControlAllowCredentials(boolean accessControlAllowCredentials) {
		this.accessControlAllowCredentials = accessControlAllowCredentials;
	}

	public boolean isCorsConfigurationEnabled() {
		return corsConfigurationEnabled;
	}

	public void setCorsConfigurationEnabled(boolean corsConfigurationEnabled) {
		this.corsConfigurationEnabled = corsConfigurationEnabled;
	}

	public List<String> getAccessControlAllowHeaders() {
		return accessControlAllowHeaders;
	}

	public void setAccessControlAllowHeaders(List<String> accessControlAllowHeaders) {
		this.accessControlAllowHeaders = accessControlAllowHeaders;
	}

	public List<String> getAccessControlAllowMethods() {
		return accessControlAllowMethods;
	}

	public void setAccessControlAllowMethods(List<String> accessControlAllowMethods) {
		this.accessControlAllowMethods = accessControlAllowMethods;
	}

}
