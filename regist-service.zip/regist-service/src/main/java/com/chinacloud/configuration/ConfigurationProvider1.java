package com.chinacloud.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ConfigurationProvider1 {

	public static String HEADER;
	
	@Value("${registService.header}")
    public void setHeader(String header) {
    	HEADER = header;
    }
}
