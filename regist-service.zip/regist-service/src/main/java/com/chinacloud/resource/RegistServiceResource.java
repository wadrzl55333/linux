/**
 * 
 */
package com.chinacloud.resource;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.chinacloud.common.ResponseObject;
import com.chinacloud.service.RegistServiceService;

@Controller
@RequestMapping("/test")
public class RegistServiceResource {

	@Autowired
	private RegistServiceService registServiceService;

//	@RequestMapping(value = "/aaa")
//	public ResponseEntity<Map<String, Object>> registSerivce() {
//
//		ResponseObject<Map<String, Object>> result = registServiceService.RegistServiceOverviw();
//		String id = result.getData().get("serviceId").toString();
//		Map<String, Object> resultMap = new HashMap();
//		resultMap.put("id", id);
//		return ResponseEntity.ok(resultMap);
//	}

	@RequestMapping(value = "/bbb")
	public ResponseObject<Map<String, Object>> registSerivce2() {
		String serviceid = registServiceService.RegistServiceOverviw().getData().get("serviceId").toString();
		String id=registServiceService.RegistServiceOverviw2(serviceid).getData().get("id").toString();
		ResponseObject<Map<String, Object>> result = registServiceService.RegistServiceOverviw2(serviceid);
		result = registServiceService.RegistServiceOverviw3(serviceid);
		registServiceService.RegistServiceOverviw4(serviceid,id);
		return result;
	}

//	@RequestMapping(value = "/ccc")
//	public ResponseObject<Map<String, Object>> registService3() {
//		ResponseObject<Map<String, Object>> result = registServiceService.RegistServiceOverviw3();
//		return result; 
//	}
//	
//	@RequestMapping(value = "/ddd")
//	public ResponseObject<Map<String, Object>> registService4() {
//		String id = registServiceService.RegistServiceOverviw().getData().get("serviceId").toString();
//		ResponseObject<Map<String, Object>> result = registServiceService.RegistServiceOverviw4(id);
//		return result; 
//	}
}
