package com.mhy.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class MessageConfiguration {

	public static String TXT_PATH;

	@Value("${message.txtPath}")
	public void setTxtPath(String txtPath) {
		TXT_PATH = txtPath;
	}
}
