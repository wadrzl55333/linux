package com.mhy.service;

public class MessageService {

}
