package com.mhy.resource;

import static com.mhy.configuration.MessageConfiguration.TXT_PATH;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.UUID;

import org.mockito.internal.util.collections.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jayway.jsonpath.internal.function.text.Concatenate;
import com.mhy.dto.MessageDto;

@RestController
public class MessageResource {

	@Autowired
	private MessageDto messageDto;

	/*
	 * @RequestMapping("/message") public String[] showMessage() throws
	 * InterruptedException { try { File readFile = new File(TXT_PATH);
	 * InputStreamReader read = new InputStreamReader(new
	 * FileInputStream(readFile), "UTF-8"); BufferedReader reader = new
	 * BufferedReader(read);
	 * 
	 * System.out.println("以行为单位读取文件内容，一次读一整行：");
	 * 
	 * String tempString = null; int line = 1; // 一次读入一行，直到读入null为文件结束
	 * 
	 * while ((tempString = reader.readLine()) != null) { System.out.println(
	 * "line " + line + ": " + tempString); String[] temp = tempString.split(" "
	 * ); messageDto.setId(temp[0]); messageDto.setName(temp[1]);
	 * messageDto.setNumber(temp[2]); Thread.sleep(2000);
	 * //str=str.Concat(temp).ToArray(); line=line+1; return temp; } } catch
	 * (IOException e) { // TODO Auto-generated catch block e.printStackTrace();
	 * } return null; }
	 */
	@RequestMapping("/message")
	public String[] showMessage() throws InterruptedException {
		String[] str = null;
		try {
			File readFile = new File(TXT_PATH);
			InputStreamReader read = new InputStreamReader(new FileInputStream(readFile), "UTF-8");
			BufferedReader reader = new BufferedReader(read);

			System.out.println("以行为单位读取文件内容，一次读一整行：");

			String tempString = null;
			int line = 1;
			// 一次读入一行，直到读入null为文件结束

			while ((tempString = reader.readLine()) != null) {
				System.out.println("line " + line + ": " + tempString);
				String[] temp = tempString.split(" ");
				messageDto.setId(temp[0]);
				messageDto.setName(temp[1]);
				messageDto.setNumber(temp[2]);
				Thread.sleep(2000);
				/* str=(String[])ArrayUtils.addAll(str, temp); */
				str = temp;
				line = line + 1;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return str;
	}

}
