﻿# nginx统一代理设置方案

标签（空格分隔）： docker

---

## 一.安装[registrator][1](容器状态监听组件) ##
 - 依赖说明：
 1.本地已安装[docker][2]服务。
 2.在mir服务中需要添加如下全局变量(不能包含http://)
> ENV_ETCD_SERVER=172.16.70.73:2379

 - 安装：
    1.下载
    ```
    $ docker pull gliderlabs/registrator:latest
    ```
    
    2.启动
    ```
    $ docker run -d \
    --name=registrator \
    --net=host -P \
    --volume=/var/run/docker.sock:/tmp/docker.sock \
    -l namespace=system \
    --restart always \
    gliderlabs/registrator:latest \
    -ip=$SCALR_EXTERNAL_IP \
        -ttl=90 \
        -ttl-refresh=60 \
    etcd://$ENV_ETCD_SERVER/mir/appmnt/stacks
    ```

3.启动命令说明

 - Docker Options
Option | Required | Description
----|------|----
--volume=/var/run/docker.sock:/tmp/docker.sock | yes  | Allows Registrator to access Docker API
--net=host | recommended  | Helps Registrator get host-level IP and hostname


 - Docker Options

Option  |	Since |	Description
----|------|----
-internal |		|Use exposed ports instead of published ports
-ip <ip address>|		|Force IP address used for registering services
-retry-attempts <number>|	v7	|Max retry attempts to establish a connection with the backend
-retry-interval <milliseconds>|	v7	|Interval (in millisecond) between retry-attempts
-tags <tags>|	v5	|Force comma-separated tags on all registered services
-deregister <mode>|	v6	|Deregister existed services "always" or "on-success". Default: always
-ttl <seconds>|		|TTL for services. Default: 0, no expiry (supported backends only)
-ttl-refresh <seconds>|		|Frequency service TTLs are refreshed (supported backends only)  [-ttl must be greater than -ttl-refresh]
-resync <seconds>|	v6	|Frequency all services are resynchronized. Default: 0, never


## 二.安装[confd][3] ##
- 依赖说明：
 1.本地已安装nginx服务。

- 安装：
    1.下载
    ```
    $ cd /opt
$ wget https://github.com/kelseyhightower/confd/releases/download/v0.11.0/confd-0.11.0-linux-amd64
    $ mv confd-0.11.0-linux-amd64 confd
$ chmod -R 755 confd
    ```

    2.创建confdir目录
    存放模板文件和资源配置文件
    ```
    $ sudo mkdir -p /etc/confd/{conf.d,templates}
    ```
    
    3.创建confd [TOML][4]配置文件
    vim /etc/confd/conf.d/mir_nginx_config.toml
    nginx配置文件输出地址：/etc/nginx/conf.d/mir_nginx.conf
    ```
    [template]
    prefix = "/mir/appmnt"
    src = "mir_nginx.conf.tmpl"
    dest = "/opt/nginx/mir_nginx.conf"
    keys = [
    	"/stacks"
    ]
    check_cmd = "nginx -t"
    reload_cmd = "nginx -s reload"

    ```
    
    4.创建[模版][5]文件
    /etc/confd/templates/mir_nginx.conf.tmpl
    <font color="red">关键点说明："175"、"121"为代理目标应用所属mir应用堆栈ID。</font>

    ```    
    {{range $farm_id := lsdir "/stacks"}}
	{{$stacks_dir := printf "/stacks/%s" $farm_id}}
	{{if eq "175" $farm_id}}
		upstream jwzh-main {
			{{range $farm_role_id := lsdir $stacks_dir}}
				{{$roles_dir := printf "/stacks/%s/%s" $farm_id $farm_role_id}}
				{{range $container_name := lsdir $roles_dir}}
				{{$container_dir := printf "/stacks/%s/%s/%s/*" $farm_id $farm_role_id $container_name}}
					{{range gets $container_dir}}
						server {{.Value}};
					{{end}}
				{{end}}
			{{end}}
		}
		server {
			listen       80;
			server_name  localhost;
			access_log /var/log/nginx/mir.appmnt.stacks.jwzh-main.access.log;
			error_log /var/log/nginx/mir.appmnt.stacks.jwzh-main.error.log;
			location / { 
				proxy_pass http://jwzh-main;
				proxy_set_header X-Real-IP          $remote_addr;
				proxy_set_header X-Forwarded-For    $proxy_add_x_forwarded_for;
				proxy_set_header Host $host:$server_port;
				proxy_set_header X-Forwarded-Proto "https";
				proxy_set_header X-Forwarded-Host $host;
				proxy_set_header X-Forwarded-Server $host;
				proxy_set_header X-Real-IP $remote_addr;
				index  index.html index.htm index.jsp;
			}
		}
	{{else if eq "121" $farm_id}}
		upstream jwzh-syrk {
			{{range $farm_role_id := lsdir $stacks_dir}}
				{{$roles_dir := printf "/stacks/%s/%s" $farm_id $farm_role_id}}
				{{range $container_name := lsdir $roles_dir}}
				{{$container_dir := printf "/stacks/%s/%s/%s/*" $farm_id $farm_role_id $container_name}}
					{{range gets $container_dir}}
						server {{.Value}};
					{{end}}
				{{end}}
			{{end}}
		}
		server {
			listen       80;
			server_name  localhost;
			access_log /var/log/nginx/mir.appmnt.stacks.jwzh-syrk.access.log;
			error_log /var/log/nginx/mir.appmnt.stacks.jwzh-syrk.error.log;
			location / { 
				proxy_pass http://jwzh-syrk;
				proxy_set_header X-Real-IP          $remote_addr;
				proxy_set_header X-Forwarded-For    $proxy_add_x_forwarded_for;
				proxy_set_header Host $host:$server_port;
				proxy_set_header X-Forwarded-Proto "https";
				proxy_set_header X-Forwarded-Host $host;
				proxy_set_header X-Forwarded-Server $host;
				proxy_set_header X-Real-IP $remote_addr;
				index  index.html index.htm index.jsp;
			}
		}
	{{end}}
{{end}}
    

    ```
    
    5.启动
    ```
    /opt/confd -backend etcd -node http://172.16.70.73:2379 -log-level debug -watch true
    ```
    
    > confd帮助命令
    /opt/confd --help
    


  [1]: http://gliderlabs.com/registrator/latest/user/quickstart/ "registrator参考资料"
  [2]: https://docs.docker.com/engine/installation/linux/ "docker文档"
  [3]: https://github.com/kelseyhightower/confd/blob/master/docs/installation.md "confd参考资料"
  [4]: https://github.com/toml-lang/toml "TOML参考文档"
  [5]: https://github.com/kelseyhightower/confd/blob/master/docs/templates.md "模版文件说明"