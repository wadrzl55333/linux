package com.whitehole.isv.spring.boot.event.esb.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.concurrent.TimeoutException;

import javax.annotation.PostConstruct;

import mousio.etcd4j.EtcdClient;
import mousio.etcd4j.responses.EtcdAuthenticationException;
import mousio.etcd4j.responses.EtcdException;
import mousio.etcd4j.responses.EtcdKeysResponse;

@Service
public class StandardETCDService {

	private EtcdClient client;

	@Value("${nginx.ip}")
	private String[] serviceBrokers;

	/*
	 * @Value("${mir.appstack.docker.response.event.prefix}") private String
	 * appstackEventPrefix;
	 */

	@PostConstruct
	public void initialize() {
		if (serviceBrokers == null || serviceBrokers.length <= 0) {
			return;
		}
		URI[] uris = new URI[serviceBrokers.length];

		for (int i = 0; i < serviceBrokers.length; i++) {
			uris[i] = URI.create(serviceBrokers[i]);
		}

		this.client = new EtcdClient(uris);
		// addEventWatch(appstackEventPrefix);
	}

	public void sendAndGet(String key, String value) {
		try {
			EtcdKeysResponse response = client.put(key, value).send().get();
			System.out.println(response);
			// log.info(">>>>>> Send ETCD message:: {}", response.node.value);

		} catch (EtcdException | IOException | EtcdAuthenticationException | TimeoutException e) {
			System.out.println("sendAndGet");

		}
	}

	public static String read(String filePath) {
		// 读取txt内容为字符串
		StringBuffer txtContent = new StringBuffer();
		// 每次读取的byte数
		byte[] b = new byte[8 * 1024];
		InputStream in = null;
		try {
			// 文件输入流
			in = new FileInputStream(filePath);
			while (in.read(b) != -1) {
				// 字符串拼接
				txtContent.append(new String(b));
			}
			// 关闭流
			in.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return txtContent.toString();
	}

	/*
	 * 监听方法
	 */
	// private void addEventWatch(String apiEventPrefix) {
	// try {
	// EtcdResponsePromise<EtcdKeysResponse> response =
	// this.client.getDir(apiEventPrefix).recursive().waitForChange().send();
	//
	// response.addListener(promise -> {
	// addEventWatch(apiEventPrefix);
	// if (response.getNow() != null) {
	// EtcdKeysResponse.EtcdNode node = response.getNow().node;
	// if (StringUtils.hasText(node.value)) {
	// //应用堆栈的docker启动后 将容器关联到应用堆栈
	// if (node.key.startsWith(appstackEventPrefix)) {
	// try {
	// handleFactory.handle(EventType.DockerEvent, response.get());
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }
	// }
	// }
	// });
	// } catch (IOException e) {
	// e.printStackTrace();
	// }
	// }
}
