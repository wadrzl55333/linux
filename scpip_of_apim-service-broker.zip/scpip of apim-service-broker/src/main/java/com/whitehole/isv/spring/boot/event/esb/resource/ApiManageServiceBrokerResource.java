/**
 * 
 */
package com.whitehole.isv.spring.boot.event.esb.resource;

import static com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider.API_MANAGER_NGINXENDPOINT;
import static com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider.WSO2CARBON;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.whitehole.isv.spring.boot.event.esb.constant.EsbServiceBrokerConstants;
import com.whitehole.isv.spring.boot.event.esb.entity.APIMApplication;
import com.whitehole.isv.spring.boot.event.esb.entity.APIMSubscription;
import com.whitehole.isv.spring.boot.event.esb.entity.APIMToken;
import com.whitehole.isv.spring.boot.event.esb.entity.AmApi;
import com.whitehole.isv.spring.boot.event.esb.entity.EventErrorCode;
import com.whitehole.isv.spring.boot.event.esb.entity.EventStatus;
import com.whitehole.isv.spring.boot.event.esb.entity.ResultObject;
import com.whitehole.isv.spring.boot.event.esb.service.APIManagerService;
import com.whitehole.isv.spring.boot.event.esb.service.ApiServiceForDatabase;
import com.whitehole.isv.spring.boot.event.esb.service.NginxConfigurationService;
import com.whitehole.isv.spring.boot.event.esb.util.ESBUtil;

/**
 * @author zhangmenghao
 *
 */
@RestController
@RequestMapping("/v2")
public class ApiManageServiceBrokerResource {
	private static Log logger = LogFactory.getLog(ApiManageServiceBrokerResource.class);

	@Autowired
	private APIManagerService APIManagerService;
	@Autowired
	private ApiServiceForDatabase apiServiceForDatabase;

	@Autowired
	private NginxConfigurationService nginxConfigurationService;

	// private static Pattern reg = Pattern.compile("(:[\\w-]+)[/]{0,1}");

	private Pattern urlPattern = Pattern.compile("^(http|https)://([\\w-]+.)+[\\w-]+(/[./?%&=]*)?$");

	private ExecutorService es;

	private int flowPoolQueueNum = 1000;

	private int flowPoolNum = 10;

	// private final static String PASSWORD = "wso2123";

	private BlockingQueue<Runnable> queue;

	private final static int BUFFER_SIZE = 4096;

	private Map<String, String> oneMarketHeaders;

	@PostConstruct
	public void initialize() {

	}

	@RequestMapping(value = "/test")
	public static void main(String[] arg) {
		try {
			System.out.println((false ? "/px" + "bbb" : "" + "aaa"));
			// System.setProperty("javax.net.ssl.trustStore", WSO2CARBON);
			//// System.setProperty("javax.net.ssl.trustStore",
			// "E:\\esb-service-broker\\esb-servicebroker\\wso2carbon.jks");
			// System.setProperty("javax.net.ssl.trustStorePassword",
			// "wso2carbon");
			// File readFile = new File("D:\\对接系统\\jwzh-api\\标准地址.txt");
			// FileOutputStream out=new
			// FileOutputStream("D:\\对接系统\\jwzh-api\\标准地址接口录入脚本(px).txt");
			// BufferedReader reader = null;
			// PrintStream p=new PrintStream(out);
			// System.out.println("以行为单位读取文件内容，一次读一整行：");
			// reader = new BufferedReader(new FileReader(readFile));
			// String tempString = null;
			// int line = 1;
			// // 一次读入一行，直到读入null为文件结束
			// while ((tempString = reader.readLine()) != null) {
			// // 显示行号
			// System.out.println("line " + line + ": " + tempString);
			// String[] temp = tempString.split(" ");
			// p.println("URL GOTO=https://localhost:9443/publisher/apis");
			// p.println("TAG POS=1 TYPE=A ATTR=TXT:Add<SP>New<SP>API");
			// p.println("TAG POS=1 TYPE=DIV ATTR=TXT:Design<SP>New<SP>API");
			// p.println("TAG POS=1 TYPE=BUTTON FORM=NAME:NoFormName
			// ATTR=ID:designNewAPI");
			// p.println("TAG POS=1 TYPE=INPUT:TEXT FORM=ID:design_form
			// ATTR=ID:name CONTENT="+temp[0]);
			// p.println("TAG POS=1 TYPE=INPUT:TEXT FORM=ID:design_form
			// ATTR=ID:context CONTENT=px/"+temp[1]);
			// p.println("TAG POS=1 TYPE=INPUT:TEXT FORM=ID:design_form
			// ATTR=ID:version CONTENT="+temp[2]);
			// p.println("TAG POS=1 TYPE=INPUT:TEXT FORM=ID:design_form
			// ATTR=ID:resource_url_pattern CONTENT="+temp[3]);
			// if(temp[5].equals("POST"))
			// {
			// p.println("TAG POS=1 TYPE=SPAN ATTR=TXT:post");
			// p.println("TAG POS=2 TYPE=INPUT:CHECKBOX FORM=ID:design_form
			// ATTR=* CONTENT=YES");
			// }
			// else{
			// p.println("TAG POS=1 TYPE=SPAN ATTR=TXT:get");
			// p.println("TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ID:design_form
			// ATTR=* CONTENT=YES");
			// }
			// p.println("TAG POS=1 TYPE=BUTTON FORM=ID:design_form
			// ATTR=ID:add_resource");
			// p.println("TAG POS=1 TYPE=A ATTR=ID:go_to_implement");
			// p.println("WAIT SECONDS=10");
			// p.println("TAG POS=1 TYPE=DIV ATTR=TXT:Managed<SP>API");
			// p.println("TAG POS=1 TYPE=INPUT:TEXT FORM=ID:implement_form
			// ATTR=* CONTENT="+temp[4]);
			// p.println("TAG POS=2 TYPE=INPUT:TEXT FORM=ID:implement_form
			// ATTR=* CONTENT="+temp[4]);
			// p.println("TAG POS=1 TYPE=SPAN ATTR=CLASS:helper&&TXT:");
			// p.println("TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ID:implement_form
			// ATTR=NAME:cors_check CONTENT=YES");
			// p.println("TAG POS=1 TYPE=BUTTON FORM=ID:implement_form
			// ATTR=ID:go_to_manage");
			// p.println("WAIT SECONDS=3");
			// p.println("TAG POS=1 TYPE=SPAN
			// ATTR=TXT:Unlimited<SP>:<SP>Allows<SP>unlimited<SP>requests");
			// p.println("TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ID:manage_form
			// ATTR=NAME:tier CONTENT=YES");
			// p.println("TAG POS=1 TYPE=A ATTR=ID:publish_api");
			// p.println("WAIT SECONDS=5");
			// p.println("TAG POS=2 TYPE=A ATTR=TXT:Go<SP>to<SP>Overview");
			// p.println("TAG POS=1 TYPE=A ATTR=TXT:Go<SP>Back");
			// p.println("WAIT SECONDS=10");
			// p.println("");
			// }
			//
			// reader.close();
			// p.close();
			//
			//
			//
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Isv对接Whitehole事件通知地址API
	 * 
	 * @return 事件处理结果
	 */
	@RequestMapping(value = "/event/**")
	public ResponseEntity<Map<String, Object>> isvEventDoAnything(HttpServletRequest request) {
		// http://10.111.135.9:8082/esb-service-broker/v1/event/api?
		// http://10.111.135.9:8082/esb-service-broker/v1/event/testDSS
		System.setProperty("javax.net.ssl.trustStore", WSO2CARBON);
		// System.setProperty("javax.net.ssl.trustStore",
		// "E:\\esb-service-broker\\esb-servicebroker\\wso2carbon.jks");
		System.setProperty("javax.net.ssl.trustStorePassword", "wso2carbon");
		Map<String, Object> result = new HashMap<String, Object>();
		// String regex =
		// "^(http|https)://([\\w-]+.)+[\\w-]+(/[\\w-./?%&=]*)?$";
		String requestUrl = request.getRequestURL().toString();
		// 请求服务的后缀
		String serviceRegex = requestUrl.substring(requestUrl.indexOf("event") + 5);
		String url = request.getParameter("url");
		logger.info("receive event handler request: url:[{}], serviceRegex:[{}]");
		if ("{eventUrl}".equals(url)) {
			result.put("code", 200);
			result.put("msg", "success");
		} else if (null != url && urlPattern.matcher(url).matches()) {
			do {
				JsonNode eventData;
				String type;
				String tenantName;
				Map<String, String> headers = new HashMap<String, String>();
				List<NameValuePair> data = new ArrayList<NameValuePair>();
				try {
					// Post request to get the event data
					eventData = ESBUtil.toJson(ESBUtil.httpClientPostUrl(headers, url, data)).get("data");
					type = eventData.get("type").textValue();
					tenantName = eventData.get("payload").get("tenant").get("name").textValue();

				} catch (Exception e) {
					result.put("success", false);
					result.put("message", "获取事件数据失败, " + e.getMessage());
					break;
				}

				if (EsbServiceBrokerConstants.EVENT_TYPE_ORDER.equals(type)) {
					// 异步订单事件处理
					result = this.isvEventOrderNonInteractiveDoAnything(serviceRegex, eventData, tenantName);
				} else if (EsbServiceBrokerConstants.EVENT_TYPE_CANCEL.equals(type)) {
					// 销毁事件处理
					result = this.isvEventCancelDoAnything(eventData);
				} else if (EsbServiceBrokerConstants.EVENT_TYPE_QUERY.equals(type)) {
					// 查询事件处理
					// result = this.isvEventQueryDoAnything(service,
					// eventData);
				} else if (EsbServiceBrokerConstants.EVENT_TYPE_SUSPEND.equals(type)) {
					// 挂起事件处理
					// result = this.isvEventSuspendDoAnything(service,
					// eventData);
				} else if (EsbServiceBrokerConstants.EVENT_TYPE_ACTIVE.equals(type)) {
					// 激活事件处理
					// result = this.isvEventActiveDoAnything(service,
					// eventData);
				} else if (EsbServiceBrokerConstants.EVENT_TYPE_CHANGE.equals(type)) {
					// 变更事件处理
					// result = this.isvEventChangeDoAnything(service,
					// eventData);
				} else if (EsbServiceBrokerConstants.EVENT_TYPE_NOTICE.equals(type)) {
					// 通知事件处理
					// result = this.isvEventNoticeDoAnything(service,
					// eventData);
				} else {
					result.put("success", false);
					result.put("message", "事件类型不支持: " + type);
					break;
				}
			} while (false);
			logger.info("Message for result: " + result.get("message"));
		} else {
			result.put("code", 400);
			result.put("msg", "url not valid");
		}
		return ResponseEntity.ok(result);
	}

	/**
	 * Isv对接Whitehole异步订单事件处理
	 * 
	 * @param eventData
	 *            异步订单事件相关数据
	 * @return 异步订单事件处理结果
	 */
	private Map<String, Object> isvEventOrderNonInteractiveDoAnything(String serviceRegex, JsonNode eventData,
			String tenantName) {
		logger.info("Isv对接Whitehole异步订单事件处理：解析事件数据......");
		Map<String, Object> result = new HashMap<String, Object>();
		Map<String, Object> process = new HashMap<String, Object>();
		// 异步订单事件处理，可以做任何事
		logger.info("Isv对接Whitehole异步订单事件处理：正在处理事件......");

		ResultObject ret1 = new ResultObject();
		try {
			ret1 = createInst(tenantName, serviceRegex, eventData);
		} catch (Exception e) {
			logger.error("Exception occurs when create task to event order. Exception message: " + e.getMessage());
			process.put("eventId",
					eventData.has("eventId") ? eventData.get("eventId").textValue() : UUID.randomUUID().toString());
			process.put("status", EventStatus.FAILD.toString());
			process.put("instanceId", "");
			result = ESBUtil.toJsonNodeErrorResult(false, process, String.valueOf(EventErrorCode.CREATE_TASK_FAIL),
					"创建服务实例异常: " + e.getMessage());
			return result;
		}

		// 异步订单事件处理结果
		logger.info("Isv对接Whitehole异步订单事件处理：组装处理结果并返回Whitehole......");

		process.put("eventId", ret1.getResult().toString());
		process.put("instanceId", "");
		if (ret1.isSuccess()) {
			process.put("status", EventStatus.WAIT_FOR_RESULT.toString());
			result = ESBUtil.toJsonNodeSuccessResult(true, process, "申请事件正在处理中");
		} else {
			process.put("status", EventStatus.FAILD.toString());
			result = ESBUtil.toJsonNodeErrorResult(false, process, ret1.getCode(), ret1.getMessage());
		}

		return result;
	}

	/**
	 * Isv对接Whitehole销毁订单事件处理
	 * 
	 * @param eventData
	 *            同步订单事件相关数据
	 * @return 同步订单事件处理结果
	 */
	private Map<String, Object> isvEventCancelDoAnything(JsonNode eventData) {
		System.out.println("Isv对接Whitehole销毁订单事件处理：解析事件数据......");
		Map<String, Object> result = new HashMap<String, Object>();
		// JsonNode returnUrl = eventData.get("returnUrl");
		// 同步订单事件处理，可以做任何事
		System.out.println("Isv对接Whitehole销毁事件处理：正在处理事件......");
		ResultObject ret1 = new ResultObject();
		ret1 = deleteInst(eventData);
		// 同步订单事件处理结果
		System.out.println("Isv对接Whitehole销毁订单事件处理：组装处理结果并返回Whitehole......");
		if (ret1.isSuccess()) {
			result.put("instanceId", "xxx");
			result.put("success", true);
			result.put("message", ret1.getMessage());
		} else {
			result = ESBUtil.toJsonNodeErrorResult(false, ret1.getCode(), ret1.getMessage());
		}
		return result;
	}

	public ResultObject createInst(final String tenantName, final String service, final JsonNode eventData) {
		ResultObject ret = new ResultObject();
		final String serviceFlavor;
		final String projectId = eventData.get("payload").get("project").get("projectId").textValue();
		final String limitIp = eventData.get("payload").get("project").get("ip").textValue();
		// String accessToken = "";
		try {
			System.out.println(eventData.asText());
			serviceFlavor = eventData.get("payload").get("order").get("editionCode").textValue();
		} catch (Exception e) {
			ret.setResult(
					eventData.has("eventId") ? eventData.get("eventId").textValue() : UUID.randomUUID().toString());
			ret.setMessage("获取事件中'editionCode'字段失败");
			ret.setCode(String.valueOf(EventErrorCode.FLAVOR_NOT_VALID.getValue()));
			return ret;
		}
		String message = "创建服务订单任务下发";

		// Instances instances = new Instances();
		// if (eventData.has("eventId")) {
		// instances.setEventId(eventData.get("eventId").textValue());
		// } else {
		// instances.setEventId(UUID.randomUUID().toString());
		// }
		ret.setResult(UUID.randomUUID().toString());
		// instances.setCreatorId(eventData.get("creator").get("id").textValue());
		// instances.setEventType(eventData.get("type").textValue());
		// instances.setEventData(eventData.toString());
		// instances.setServiceFlavor(serviceFlavor);
		// instances.setResult("{}");
		// instances.setServiceName(service);
		// final String instanceId = UUID.randomUUID().toString();
		// instances.setServiceInstanceId(instanceId);
		System.out.println("ServiceFlavor = " + serviceFlavor);
		final APIMApplication newApplication = APIManagerService.getApplication(projectId);
		final String token = APIManagerService.getAccessToken(newApplication.getApplicationId());
		ret.setMessage(message);
		es.execute(new Runnable() {
			@Override
			public void run() {
				// 异步返回数据
				Map<String, Object> asyncResult = new HashMap<String, Object>();
				String callbackUrl = eventData.get("callBackUrl").textValue();
				String apiContext = "";
				String serviceUrlMapping = service;
				// 是否为培训环境，默认为正式
				Boolean pxFlag = false;
				AmApi amApi = new AmApi();
				APIMSubscription apiSub = new APIMSubscription();
				try {
					// 判断是否为培训，后续需要处理urlMapping
					if (service.startsWith("/px")) {
						pxFlag = true;
						serviceUrlMapping = service.substring(3, service.length());
					}
					if (null != apiServiceForDatabase.getApiByUrlPatternOrContext(serviceUrlMapping, pxFlag)) {
						amApi = apiServiceForDatabase.getApiByUrlPatternOrContext(serviceUrlMapping, pxFlag);
						apiContext = apiServiceForDatabase.getApiContextByApiId(amApi.getApiId());
						logger.info("apiContext:" + apiContext + " for search");
						apiSub = APIManagerService.subscripeByContext(apiContext, newApplication.getApplicationId(),
								pxFlag);
						asyncResult.put("success", "true");
						asyncResult.put("message", "Subscribe api success");
					} else {
						asyncResult.put("success", "false");
						asyncResult.put("message", "not find api");
					}

					logger.info("token===" + token);

					if (limitIp != null && !limitIp.isEmpty() && apiSub.getSubscriptionId() != null
							&& !apiSub.getSubscriptionId().isEmpty()) {
						apiServiceForDatabase.addLimitIp(apiContext, limitIp, apiSub.getSubscriptionId());
					}
					Map<String, Object> instance = new HashMap<String, Object>();
					Map<String, String> attrs = new HashMap<String, String>();
					attrs.put("Authorization", "Bearer " + token);
					attrs.put("api", API_MANAGER_NGINXENDPOINT + apiContext + amApi.getUrlPattern());
					attrs.put("method", serviceFlavor);
					attrs.put("apiSubId", apiSub.getSubscriptionId());
					instance.put("metadata", attrs);
					instance.put("type", "apiManage");
					Map<String, Object> process = new HashMap<String, Object>();
					process.put("eventId", eventData.get("eventId").textValue());
					process.put("status", EventStatus.SUCCESS.toString());
					process.put("instanceId", apiSub.getSubscriptionId());
					process.put("extensionUrl", "");
					process.put("instance", instance);
					asyncResult.put("process", process);
					try {
						APIMToken apiMToken = new APIMToken();
						apiMToken.setAccessToken(token);
					} catch (Exception e) {
						logger.error(e);
					}

					// else if(httpClientResp.getResponseStatus() == 409){
					//// List<APIMToken> APIMToken =
					// tokenMapper.getTokenByName(username);
					//// if(APIMToken == null || APIMToken.size()==0){
					//// TimeUnit.SECONDS.sleep(1);
					//// APIMToken = tokenMapper.getTokenByName(username);
					//// }
					//// String acceccToken = apiMToken;
					//// System.out.println("exist APIMToken = "+acceccToken);
					// JsonNode jsonNode = ESBUtil.toJson(httpClientResp
					// .getRespBody());
					// String userId = jsonNode.get("id").textValue();
					// APIMApplication apiMAapplication =
					// APIManagerService.getApplicationDetailsWithAppName(userId);
					// String acceccToken =
					// apiMAapplication.getKeys().get(0).getToken().getAccessToken();
					// asyncResult.put("success", "true");
					// Map<String,Object> instance = new
					// HashMap<String,Object>();
					// Map<String,String> attrs = new HashMap<String,String>();
					// attrs.put("Authorization",acceccToken);
					// attrs.put("method",serviceFlavor);
					//// attrs.put("api", settings.esbEndpoint+service);
					// instance.put("metadata",attrs );
					// instance.put("type", "ApiManage");
					// Map<String, Object> process = new HashMap<String,
					// Object>();
					// process.put("eventId", eventData.get("eventId")
					// .textValue());
					// process.put("status",
					// EventStatus.SUCCESS.toString());
					// process.put("instanceId", instanceId);
					// process.put("extensionUrl", "");
					// process.put("instance", instance);
					// asyncResult.put("process", process);
					// }
					// else {
					// asyncResult.put("success", "false");
					// asyncResult.put("message", "申请服务获取token失败.");
					//
					// }
				} catch (Exception e) {
					e.printStackTrace();
					logger.error(e);
					asyncResult.put("success", "false");
					asyncResult.put("message", e.getMessage());
				} finally {
					String strRet = new JSONObject(asyncResult).toString();
					callbackOneMarket(callbackUrl, strRet);
				}

			}
		});

		return ret;

	}

	@RequestMapping(value = "/delete")
	public ResponseEntity<Map<String, Object>> removeAPI(@RequestParam("context") String context) {
		Map<String, Object> result = new HashMap<String, Object>();

		try {
			APIManagerService.removeSubscription(context);
			result.put("success", true);
			result.put("message", "删除api成功 ");
		} catch (Exception e) {
			result.put("success", false);
			result.put("message", "删除api失败 " + e.getMessage());
		}

		return ResponseEntity.ok(result);
	}

	/**
	 * @param in
	 * @param encoding
	 * @return String
	 * @throws Exception
	 */
	public static String InputStreamTOString(InputStream in, String encoding) throws Exception {
		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		byte[] data = new byte[BUFFER_SIZE];
		int count = -1;
		while ((count = in.read(data, 0, BUFFER_SIZE)) != -1)
			outStream.write(data, 0, count);

		data = null;
		return new String(outStream.toByteArray(), encoding);
	}

	public void callbackOneMarket(String callbackUrl, String result) {
		try {
			System.out.println("回调onemarket==" + callbackUrl + "==" + result);
			HttpResponse resp = ESBUtil.httpClientPostUrl(oneMarketHeaders, callbackUrl, result);
			if (resp.getStatusLine().getStatusCode() != 200) {
				logger.error("回调门户失败 status = " + resp.getStatusLine().getStatusCode()
						+ InputStreamTOString(resp.getEntity().getContent(), "utf-8"));
			}
		} catch (Exception e) {
			logger.error("回调门户失败 : " + e.getMessage());
		}

	}

	public ResultObject deleteInst(JsonNode eventData) {

		ResultObject ret = new ResultObject();
		Map<String, Object> asyncResult = new HashMap<String, Object>();
		String serviceInstanceId;
		try {
			serviceInstanceId = eventData.get("payload").get("instance").get("instanceId").textValue();
			System.out.println("serviceInstanceId = " + serviceInstanceId);
		} catch (Exception e) {
			ret.setSuccess(false);
			ret.setCode(String.valueOf(EventErrorCode.EVENT_DATA_NOT_VALID.getValue()));
			ret.setMessage("获取实例编号失败," + e.getMessage());
			return ret;
		}

		try {
			// APIMToken APIMToken =
			// tokenMapper.getTokenById(serviceInstanceId);
			// HttpClientResp httpClientResp =
			// userOperation.delete(eventData.get("creator").get("id").textValue());
			String apiSubId = eventData.get("payload").get("variables").get("metadata").get("apiSubId").textValue();
			// try {
			nginxConfigurationService.deleteLimitIp(apiSubId);
			boolean cancalFlag = apiServiceForDatabase.deleteSubscription(apiSubId);
			// } catch (Exception e) {
			// // TODO Auto-generated catch block
			// ret.setSuccess(false);
			// ret.setMessage("销毁服务实例失败");
			// logger.error("销毁服务实例失败 ");
			// }
			if (cancalFlag != true) {
				ret.setSuccess(false);
				ret.setMessage("销毁服务实例失败");
				logger.error("销毁服务实例失败 . ");
			}
			// instancesMapper.deleteInstancesId(serviceInstanceId);
			// tokenMapper.deleteTokenById(serviceInstanceId);
		} catch (Exception e) {
			String message = "销毁服务实例失败";
			ret.setSuccess(false);
			ret.setMessage(message);
			logger.error(e);
			e.printStackTrace();
		}

		Map<String, Object> process = new HashMap<String, Object>();
		String callbackUrl = eventData.get("callBackUrl").textValue();
		ret.setSuccess(true);
		String message = "成功销毁服务实例";
		ret.setMessage(message);
		process.put("eventId", eventData.get("eventId").textValue());
		process.put("status", EventStatus.SUCCESS.toString());
		process.put("instanceId", serviceInstanceId);
		process.put("extensionUrl", "");
		process.put("instance", null);
		asyncResult.put("process", process);
		asyncResult.put("message", message);
		asyncResult.put("success", true);
		asyncResult.put("errorCode", "");

		String strRet = new JSONObject(asyncResult).toString();
		callbackOneMarket(callbackUrl, strRet);

		return ret;
	}

	public ApiManageServiceBrokerResource() {

		queue = new ArrayBlockingQueue<Runnable>(flowPoolQueueNum);
		es = new ThreadPoolExecutor(flowPoolNum, flowPoolNum, 1, TimeUnit.HOURS, queue,
				new ThreadPoolExecutor.CallerRunsPolicy());
		oneMarketHeaders = new HashMap<String, String>();
		oneMarketHeaders.put("Content-Type", "application/json");
	}

}
