package com.whitehole.isv.spring.boot.event.esb.entity;

/**
 * Created by zijian on 12/15/16.
 */

public class ResponseObject<T> {
    private int status = 200;
    private String message;
    private T data;

    public int getStatus() {
        return status;
    }

    public T getData() {
        return data;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ResponseObject(T data) {
        this.data = data;
    }

    public ResponseObject() {
    }
}

