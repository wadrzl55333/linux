package com.whitehole.isv.spring.boot.event.esb.service;

import com.whitehole.isv.spring.boot.event.esb.entity.LimitIp;
import com.whitehole.isv.spring.boot.event.esb.util.*;
import com.github.odiszapc.nginxparser.*;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;





/**
 * Created by zijian on 12/9/16.
 */
@Service
public class NginxConfigurationService {

	@Autowired
	private ApiServiceForDatabase apiServiceForDatabase; 
	
    private static Logger logger = LogManager.getLogger(NginxConfigurationService.class);

    @Value("${nginx.config.file.path}")
    private String nginxConfigPath;

    @Value("${nginx.config.file.bakFolder}")
    private String nginxConfigBakPath;

    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");


    public void updateWhiteList(String locationUrl, String[] ips) {
    }


	public boolean addLocationUrl(String locationUrl, String proxyPass ,String ips) {
        try {
            NgxConfig ngxConfig = NginxConfigurationFileHandler.loadFile();
            List<NgxEntry> locationBlocks = new ArrayList<NgxEntry>();
            List<NgxEntry> allChildBlocks= ngxConfig.findAll(NgxBlock.class, "http", "server", "location");
            for(NgxEntry currentBlock:allChildBlocks){
            	if(currentBlock.toString().equals("location "+locationUrl+" {")){
            		locationBlocks.add(currentBlock);
            		}
            }
//                    .stream()
//                    .filter(location -> locationUrl.equals(((NgxBlock) location).getValue()))
//                    .collect(toList());

            if (locationBlocks.size() == 0) {
                NgxBlock parentBlock = ngxConfig.findBlock("http", "server");
                NgxBlock childBlock=buildLocationBlock(locationUrl, proxyPass);
                parentBlock.addEntry(childBlock);               
                addAllowIp(childBlock,ips);
                promiseDenyAll(childBlock); 	
            } else {
            	addAllowIp(locationBlocks.get(0),ips); 
            	promiseDenyAll(locationBlocks.get(0)); 	
            }
            
            
            dumpFile(ngxConfig);
        } catch (Exception e) {
            logger.error("load nginx config file failed", e);
            return false;
        }
        return true;

    }

    /**
	 * @param parentBlock
	 * @param ips
	 */
	private void addAllowIp(NgxEntry ngxEntry, String ips) {
		// TODO Auto-generated method stub
		NgxBlock locationBlock = (NgxBlock) ngxEntry;
		String[] ipsArray = ips.split(";");
		for(int i=0;i<ipsArray.length;i++){
//			String currentIp = ipsArray[i] ;
//			System.out.println(locationBlock.findAll(NgxParam.class, "allow")
//                    .stream()
//                    .filter(allowIp -> currentIp.equals(((NgxParam) allowIp).getValue()))
//                    .collect(toList()).size());
			
//            List<NgxEntry> allAllowBlocks= locationBlock.findAll(NgxParam.class, "allow");
//            if(!allAllowBlocks.toString().contains(currentIp+";"))
//            {
            	locationBlock.addEntry(buildParam("allow", ipsArray[i]));
//            }
           
//			if(locationBlock.findAll(NgxParam.class, "allow")
//                    .stream()
//                    .filter(allowIp -> currentIp.equals(((NgxParam) allowIp).getValue()))
//                    .collect(toList()).size()==0){
//			 locationBlock.addEntry(buildParam("allow", ipsArray[i]));
//			 }
		}
		
	}

	private void dumpFile(NgxConfig ngxConfig) throws IOException {
        File cFile = new File(nginxConfigPath);
        if (!cFile.exists()) {
            throw new FileNotFoundException("can not found nginx config file with: " + nginxConfigPath);
        }
        File configBak = new File(nginxConfigBakPath);
        if(!configBak.exists()){
            configBak.mkdir();
        }
        configBak = new File(nginxConfigBakPath + "/" + sdf.format(new Date()) + ".bak");
        configBak.createNewFile();
        FileCopyUtils.copy(cFile, configBak);
        cFile.delete();
        cFile.createNewFile();
        FileOutputStream fos = new FileOutputStream(cFile);
        try {
            NgxDumper dumper = new NgxDumper(ngxConfig);
            dumper.dump(fos);
        } catch (Exception e) {
            logger.error("dump nginx file failed", e);
        } finally {
            fos.close();
        }
    }

    private NgxBlock promiseDenyAll(NgxEntry ngxEntry) {
        NgxBlock locationBlock = (NgxBlock) ngxEntry;
        if (locationBlock.findParam("deny") != null) {
        	locationBlock.remove(locationBlock.findParam("deny"));
        }     
        	locationBlock.addEntry(buildParam("deny", "all"));
        return locationBlock;
    }

    private NgxBlock buildLocationBlock(String location, String proxyPass) throws IOException {
        NgxConfig templateConfig = NginxConfigurationFileHandler.loadTemplateFile();
        NgxBlock templateConfigLocation = templateConfig.findBlock("http", "server", "location");
        templateConfigLocation.addValue(location);
        templateConfigLocation.addEntry(buildParam("proxy_pass", proxyPass));
        return templateConfigLocation;
    }

    private NgxParam buildParam(String key, String value) {
        NgxParam denyParam = new NgxParam();
        denyParam.addValue(key);
        denyParam.addValue(value);
        return denyParam;
    }




	/**
	 * @param apiSubId
	 */
	public boolean deleteLimitIp(String apiSubId) {
		// TODO Auto-generated method stub
		LimitIp limitIp = apiServiceForDatabase.getLimitIpBySubId(apiSubId);
        NgxConfig ngxConfig;
		try {
			ngxConfig = NginxConfigurationFileHandler.loadFile();
	        List<NgxEntry> locationBlocks = new ArrayList<NgxEntry>();
	        List<NgxEntry> allChildBlocks= ngxConfig.findAll(NgxBlock.class, "http", "server", "location");
            for(NgxEntry currentBlock:allChildBlocks){
            	if(currentBlock.toString().equals("location "+limitIp.getUrl()+" {")){
            		locationBlocks.add(currentBlock);
            		}
            }   
            	if (locationBlocks.size() != 0) {
                deleteAllowIp(locationBlocks.get(0),limitIp.getIp());
            }
            	else{
            		return false;
            	}
            	dumpFile(ngxConfig);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		NginxOperationUtil.reloadNginx();
		return true;
		
	}


	/**
	 * @param ngxEntry
	 * @param ip
	 */
	private NgxBlock deleteAllowIp(NgxEntry ngxEntry, String ips) {
		// TODO Auto-generated method stub
		NgxBlock locationBlock = (NgxBlock) ngxEntry;
		String[] ipsArray = ips.split(";");
		String currentIp = "";
		for(int i=0;i<ipsArray.length;i++){
		  currentIp=ipsArray[i];
          List<NgxEntry> allAllowBlocks= locationBlock.findAll(NgxParam.class, "allow");
          for(NgxEntry currentAllowBlock:allAllowBlocks)
          	{
        		  if(currentAllowBlock.toString().contains(currentIp+";"))
        		  {
        			  locationBlock.remove(currentAllowBlock);
        			  break;
        		  }
          	}
          
	}
		return locationBlock;
}


	/**
	 * @param locationUrl
	 */
	public void deleteLocationUrl(String locationUrl) {
		// TODO Auto-generated method stub
		
	}
	
	
}
