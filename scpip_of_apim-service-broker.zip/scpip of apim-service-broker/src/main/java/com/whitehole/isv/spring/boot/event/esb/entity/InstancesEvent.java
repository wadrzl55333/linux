package com.whitehole.isv.spring.boot.event.esb.entity;

public enum InstancesEvent {

    SUBSCRIPTION_CANCEL,
    SUBSCRIPTION_SUSPEND,
    SUBSCRIPTION_ACTIVE,
    SUBSCRIPTION_CHANGE,
    SUBSCRIPTION_NOTICE,
    SUBSCRIPTION_ORDER

}
