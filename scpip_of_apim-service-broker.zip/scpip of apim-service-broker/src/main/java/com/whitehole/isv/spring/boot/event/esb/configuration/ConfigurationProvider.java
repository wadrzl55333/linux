package com.whitehole.isv.spring.boot.event.esb.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by zijian on 10/10/16.
 */
@Component
public class ConfigurationProvider {

	public static String WSO2CARBON;
	
    public static String API_MANAGER_ENDPOINT;
    public static String API_APIM_ENDPOINT;
    public static String API_MANAGER_OUTENDPOINT;
    public static String API_MANAGER_NGINXENDPOINT;

    public static String ACCESS_TOKEN_SUBSCRIBE;
    public static String REFRESH_TOKEN_SUBSCRIBE;

    public static String API_APPLICATIONS_RETRIEVE;
    public static String API_APPLICATIONS_DETAILS;
    public static String API_APPLICATIONS_CREATE;
    public static String API_APPLICATIONS_GENERATE_KEY;

    public static String API_SUBSCRIPTION_ADD;
    public static String API_SUBSCRIPTION_REMOVE;
    public static String API_SUBSCRIPTION_DETAILS;
    
    public static String API_APIRESOURCE_RETRIEVE;
    
    public static String WS_DX_PORTALURL;
    public static String WS_QBLD_PORTALURL;
    public static String WS_ZZJGGL_PORTALURL;
    public static String WS_LDRK_PORTALURL;
    public static String WS_FZZZJGGL_PORTALURL;
    public static String WS_CRJGL_PORTALURL;
    
    public static String WS_PORTALURL;
    
    
    
    public static List<String> WS_LIST;

    @Value("${wso2.carbon}")
    public void setWso2Carbon(String wso2Carbon) {
    	WSO2CARBON = wso2Carbon;
    }
    
    @Value("${wso2.apim.api.application.retrieve}")
    public void setApiApplicationsRetrieve(String apiApplicationsRetrieve) {
        API_APPLICATIONS_RETRIEVE = apiApplicationsRetrieve;
    }

    @Value("${wso2.apim.api.application.details}")
    public void setApiApplicationsDetails(String apiApplicationsDetails) {
    	API_APPLICATIONS_DETAILS = apiApplicationsDetails;
    }

    @Value("${wso2.apim.api.application.create}")
    public void setApiApplicationsCreate(String apiApplicationsCreate) {
        API_APPLICATIONS_CREATE = apiApplicationsCreate;
    }

    @Value("${wso2.apim.api.application.generateKey}")
    public void setApiApplicationsGenerateKey(String apiApplicationsGenerateKey) {
        API_APPLICATIONS_GENERATE_KEY = apiApplicationsGenerateKey;
    }

    @Value("${wso2.apim.api.subscription.add}")
    public void setApiSubscriptionAdd(String apiSubscriptionAdd) {
        API_SUBSCRIPTION_ADD = apiSubscriptionAdd;
    }

    @Value("${wso2.apim.api.subscription.remove}")
    public void setApiSubscriptionRemove(String apiSubscriptionRemove) {
        API_SUBSCRIPTION_REMOVE = apiSubscriptionRemove;
    }

    @Value("${wso2.apim.api.subscription.details}")
    public void setApiSubscriptionDetails(String apiSubscriptionDetails) {
        API_SUBSCRIPTION_DETAILS = apiSubscriptionDetails;
    }

    @Value("${wso2.apim.endpoint}")
    public void setApiManagerEndpoint(String apiManagerEndpoint) {
        API_MANAGER_ENDPOINT = apiManagerEndpoint;
    }

    @Value("${wso2.apim.token.subscribe.accessToken}")
    public void setAccessTokenSubscribe(String accessTokenSubscribe) {
        ACCESS_TOKEN_SUBSCRIBE = accessTokenSubscribe;
    }

    @Value("${wso2.apim.token.subscribe.refreshToken}")
    public void setRefreshTokenSubscribe(String refreshTokenSubscribe) {
        REFRESH_TOKEN_SUBSCRIBE = refreshTokenSubscribe;
    }
    
    
    @Value("${wso2.apim.api.apiResource.retrieve}")
    public void setApiApiresourceRetrieve(String apiApiresourceRetrieve) {
    	API_APIRESOURCE_RETRIEVE = apiApiresourceRetrieve;
    }
    
    @Value("${wso2.apim.outendpoint}")
    public void setApiManagerOutEndpoint(String apiManagerOutEndpoint) {
        API_MANAGER_OUTENDPOINT = apiManagerOutEndpoint;
    }
    
    @Value("${wso2.apim.nginxendpoint}")
    public void setApiManagerNginxEndpoint(String apiManagerNginxEndpoint) {
        API_MANAGER_NGINXENDPOINT = apiManagerNginxEndpoint;
    }
	/**
	 * @param wS_DX_PORTALURL the wS_DX_PORTALURL to set
	 */
    @Value("${webservice.dx.portalurl}")
	public void setWsDxPortalurl(String wsDxPortalurl) {
		WS_DX_PORTALURL = wsDxPortalurl;
	}
    
    @Value("${webservice.qbld.portalurl}")
	public void setWsQbldPortalurl(String wsQbldPortalurl) {
    	WS_QBLD_PORTALURL = wsQbldPortalurl;
	}
    
    @Value("${webservice.zzjggl.portalurl}")
	public void setWsZzjgglPortalurl(String wsZzjgglPortalurl) {
		WS_ZZJGGL_PORTALURL = wsZzjgglPortalurl;
	}
    
    @Value("${webservice.fzzzjggl.portalurl}")
	public void setWsFzzzjgglPortalurl(String wsFzzzjgglPortalurl) {
		WS_FZZZJGGL_PORTALURL = wsFzzzjgglPortalurl;
	}
    
    @Value("${webservice.crjgl.portalurl}")
	public void setWsCrjglPortalurl(String wsCrjglPortalurl) {
		WS_CRJGL_PORTALURL = wsCrjglPortalurl;
	}
    
    @Value("${webservice.portalurl}")
	public void setPortalurl(String wsPortalurl) {
		WS_PORTALURL = wsPortalurl;
		System.out.println(WS_PORTALURL);
	}
//    @Value("${webservice.ldrk.portalurl}")
//	public void setWsLdrkPortalurl(String wsLdrkPortalurl) {
//    	WS_LDRK_PORTALURL = wsLdrkPortalurl;
//	}

}
