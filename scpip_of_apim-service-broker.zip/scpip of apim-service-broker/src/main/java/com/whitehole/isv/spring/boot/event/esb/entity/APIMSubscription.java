package com.whitehole.isv.spring.boot.event.esb.entity;

/**
 * Created by zijian on 10/10/16.
 */
public class APIMSubscription {
    private String tier;
    private String subscriptionId;
    private String apiIdentifier;
    private String applicationId;
    private String status;

    public String getTier() {
        return tier;
    }

    public void setTier(String tier) {
        this.tier = tier;
    }

    public String getSubscriptionId() {
        return subscriptionId;
    }

    public void setSubscriptionId(String subscriptionId) {
        this.subscriptionId = subscriptionId;
    }

    public String getApiIdentifier() {
        return apiIdentifier;
    }

    public void setApiIdentifier(String apiIdentifier) {
        this.apiIdentifier = apiIdentifier;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    //    {
//        "tier": "Gold",
//            "subscriptionId": "5b65808c-cdf2-43e1-a695-de63e3ad0ae9",
//            "apiIdentifier": "admin-PhoneVerification-2.0.0",
//            "applicationId": "c30f3a6e-ffa4-4ae7-afce-224d1f820524",
//            "status": "UNBLOCKED"
//    }
}
