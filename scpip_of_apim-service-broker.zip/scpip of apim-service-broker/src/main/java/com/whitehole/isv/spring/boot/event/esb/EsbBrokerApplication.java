package com.whitehole.isv.spring.boot.event.esb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Created by sg on 2017/7/5.
 */

@EnableScheduling
@SpringBootApplication
public class EsbBrokerApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(EsbBrokerApplication.class, args);        
    }
    
}
