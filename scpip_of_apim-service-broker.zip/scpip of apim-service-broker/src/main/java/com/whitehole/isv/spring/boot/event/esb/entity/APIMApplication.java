package com.whitehole.isv.spring.boot.event.esb.entity;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by zijian on 10/10/16.
 */
public class APIMApplication implements Serializable{
    private String groupId;
    private String callbackUrl;
    private String subscriber;
    private String throttlingTier;
    private String applicationId;
    private String description;
    private String status;
    private String name;
    private ArrayList<APIMApplicationKey> keys;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getCallbackUrl() {
        return callbackUrl;
    }

    public void setCallbackUrl(String callbackUrl) {
        this.callbackUrl = callbackUrl;
    }

    public String getSubscriber() {
        return subscriber;
    }

    public void setSubscriber(String subscriber) {
        this.subscriber = subscriber;
    }

    public String getThrottlingTier() {
        return throttlingTier;
    }

    public void setThrottlingTier(String throttlingTier) {
        this.throttlingTier = throttlingTier;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<APIMApplicationKey> getKeys() {
        return keys;
    }

    public void setKeys(ArrayList<APIMApplicationKey> keys) {
        this.keys = keys;
    }

    //    {
//        "groupId": null,
//            "callbackUrl": "http://my.server.com/callback",
//            "subscriber": "admin",
//            "throttlingTier": "Unlimited",
//            "applicationId": "c30f3a6e-ffa4-4ae7-afce-224d1f820524",
//            "description": "sample app description",
//            "status": "APPROVED",
//            "name": "sampleapp",
//            "keys": []
//    }
}
