package com.whitehole.isv.spring.boot.event.esb.util;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class HttpClientUtil {
	
	public static CloseableHttpClient createSSLClientDefault() {
		try {
			SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
				@Override
				public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					return true;
				}
			}).build();
			SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
			return HttpClients.custom().setSSLSocketFactory(sslsf).build();
		} catch (KeyManagementException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (KeyStoreException e) {
			e.printStackTrace();
		}
		return HttpClients.createDefault();
	}
	
	public static CloseableHttpClient getHttpClient(boolean https) {
		if(https) {
			return createSSLClientDefault();
		} else {
			return HttpClients.createDefault();
		}
    	
    }
	
	
	public static HttpResponse httpClientGetUrl(Map<String, String> headers, String url, Map<String, String> paramsMap,boolean https)
			throws Exception {
		CloseableHttpClient httpClient = getHttpClient(https);
		HttpGet httpGet = new HttpGet(url);
		if (headers != null) {
			for (Map.Entry<String, String> entry : headers.entrySet()) {
				httpGet.addHeader(entry.getKey(), entry.getValue());
			}
		}

		String params = "?";
		boolean first = true;
		if (paramsMap != null) {
			for (Map.Entry<String, String> entry : paramsMap.entrySet()) {
				if (first) {
					params = params + entry.getKey() + "=" + entry.getValue();
				} else {
					params = "&" + params + entry.getKey() + "=" + entry.getValue();
				}
				first = false;
			}
		}
		RequestConfig requestConfig = RequestConfig.custom()
				// �������ӳ�ʱʱ��
				.setConnectTimeout(30000)
				// ���ô�connect Manager��ȡConnection ��ʱʱ��
				.setConnectionRequestTimeout(30000)
				// �����ȡ���ݵĳ�ʱʱ��
				.setSocketTimeout(30000).build();
		httpGet.setConfig(requestConfig);
		return httpClient.execute(httpGet);
	}
	
	public static HttpEntity httpClientPostUrl(Map<String, String> headers, String url, Map<String, String> paramsMap,boolean https)
			throws Exception {
		CloseableHttpClient httpClient = getHttpClient(https);
		HttpGet httpGet = new HttpGet(url);
		if (headers != null) {
			for (Map.Entry<String, String> entry : headers.entrySet()) {
				httpGet.addHeader(entry.getKey(), entry.getValue());
			}
		}

		String params = "?";
		boolean first = true;
		if (paramsMap != null) {
			for (Map.Entry<String, String> entry : paramsMap.entrySet()) {
				if (first) {
					params = params + entry.getKey() + "=" + entry.getValue();
				} else {
					params = "&" + params + entry.getKey() + "=" + entry.getValue();
				}
				first = false;
			}
		}
		RequestConfig requestConfig = RequestConfig.custom()
				// �������ӳ�ʱʱ��
				.setConnectTimeout(30000)
				// ���ô�connect Manager��ȡConnection ��ʱʱ��
				.setConnectionRequestTimeout(30000)
				// �����ȡ���ݵĳ�ʱʱ��
				.setSocketTimeout(30000).build();
		httpGet.setConfig(requestConfig);
		return httpClient.execute(httpGet).getEntity();
	}
}
