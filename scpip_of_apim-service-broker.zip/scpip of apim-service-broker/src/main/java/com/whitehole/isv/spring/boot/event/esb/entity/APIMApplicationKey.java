package com.whitehole.isv.spring.boot.event.esb.entity;

/**
 * Created by zijian on 10/10/16.
 */
public class APIMApplicationKey {
    private String consumerSecret;
    private String consumerKey;
    private String keyState;
    private String keyType;
    private String[] supportedGrantTypes;
    private APIMToken token;

    public String getConsumerSecret() {
        return consumerSecret;
    }

    public void setConsumerSecret(String consumerSecret) {
        this.consumerSecret = consumerSecret;
    }

    public String getConsumerKey() {
        return consumerKey;
    }

    public void setConsumerKey(String consumerKey) {
        this.consumerKey = consumerKey;
    }

    public String getKeyState() {
        return keyState;
    }

    public void setKeyState(String keyState) {
        this.keyState = keyState;
    }

    public String getKeyType() {
        return keyType;
    }

    public void setKeyType(String keyType) {
        this.keyType = keyType;
    }

    public APIMToken getToken() {
        return token;
    }

    public void setToken(APIMToken token) {
        this.token = token;
    }

	/**
	 * @return the supportedGrantTypes
	 */
	public String[] getSupportedGrantTypes() {
		return supportedGrantTypes;
	}

	/**
	 * @param supportedGrantTypes the supportedGrantTypes to set
	 */
	public void setSupportedGrantTypes(String[] supportedGrantTypes) {
		this.supportedGrantTypes = supportedGrantTypes;
	}
    
    //    {
//        "consumerSecret":"8V7DDKtKGtuG_9GDjaOJ5sijdX0a",
//        "consumerKey":"LOFL8He72MSGVil4SS_bsh9O8MQa",
//        "keyState":"APPROVED",
//        "keyType":"PRODUCTION",
//        "supportedGrantTypes":[
//            "urn:ietf:params:oauth:grant-type:saml2-bearer",
//            "iwa:ntlm",
//            "refresh_token",
//            "client_credentials",
//            "password"
//        ],
//        "token":{
//        "validityTime":3600,
//        "accessToken":"fd2cdc4906fbc162e033d57f85a71c21",
//        "tokenScopes":[
//            "am_application_scope",
//            "default"
//        ]
//    }
//    }
}
