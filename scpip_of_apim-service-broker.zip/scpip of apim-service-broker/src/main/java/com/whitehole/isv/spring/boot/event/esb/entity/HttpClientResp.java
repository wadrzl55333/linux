package com.whitehole.isv.spring.boot.event.esb.entity;

public class HttpClientResp {
	
	private int responseStatus;
	private String respBody;
	
	public int getResponseStatus() {
		return responseStatus;
	}
	public void setResponseStatus(int responseStatus) {
		this.responseStatus = responseStatus;
	}
	public String getRespBody() {
		return respBody;
	}
	public void setRespBody(String respBody) {
		this.respBody = respBody;
	}
	
	

}
