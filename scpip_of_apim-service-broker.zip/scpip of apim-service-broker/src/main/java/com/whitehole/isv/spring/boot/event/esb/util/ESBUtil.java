package com.whitehole.isv.spring.boot.event.esb.util;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.LaxRedirectStrategy;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Created by tony on 16-一月-22.
 */
public class ESBUtil {

    public static Map<String, Object> toJsonNodeSuccessResult(boolean success, String instanceId, String message) {
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("success", success);
        result.put("instanceId", instanceId);
        result.put("message", message);

        return result;
    }

    public static Map<String, Object> toJsonNodeErrorResult(boolean success, String errorCode, String message) {
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("success", success);
        result.put("errorCode", errorCode);
        result.put("message", message);

        return result;
    }

    public static Map<String, Object> toJsonNodeSuccessResult(boolean success, Map<String, Object> process, String message) {
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("success", success);
        result.put("process", process);
        result.put("message", message);

        return result;
    }

    public static Map<String, Object> toJsonNodeErrorResult(boolean success, Map<String, Object> process, String errorCode, String message) {
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("success", success);
        result.put("process", process);
        result.put("errorCode", errorCode);
        result.put("message", message);

        return result;
    }

    public static HttpResponse httpClientGetUrl(Map<String, String> headers, String url) throws Exception {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(url);

        for(Map.Entry<String, String> entry: headers.entrySet()) {
            httpGet.addHeader(entry.getKey(), entry.getValue());
        }
        RequestConfig requestConfig = RequestConfig.custom()
                //设置连接超时时间
                .setConnectTimeout(30000)
                        //设置从connect Manager获取Connection 超时时间
                .setConnectionRequestTimeout(30000)
                        //请求获取数据的超时时间
                .setSocketTimeout(30000).build();
        httpGet.setConfig(requestConfig);
        return httpClient.execute(httpGet);
    }

    public static HttpResponse httpClientGetUrl(String url) throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        return httpClientGetUrl(headers, url);
    }


    public static HttpResponse httpClientPostUrl(Map<String, String> headers, String url, String data) throws  Exception {
//        HttpClientBuilder hcBuilder = HttpClients.custom();
//        hcBuilder.setRedirectStrategy(new LaxRedirectStrategy());
        CloseableHttpClient httpClient = HttpClients.createDefault();
//        CloseableHttpClient httpClient = hcBuilder.build();
        //httpClient.getParams().setParameter("http.protocol.allow-circular-redirects", true);
        HttpPost httpPost = new HttpPost(url);
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            httpPost.addHeader(entry.getKey(), entry.getValue());
        }
        httpPost.setEntity(new StringEntity(data));
        RequestConfig requestConfig = RequestConfig.custom()
                //设置连接超时时间
                .setConnectTimeout(30000)
                        //设置从connect Manager获取Connection 超时时间
                .setConnectionRequestTimeout(30000)
                        //请求获取数据的超时时间
                .setSocketTimeout(30000)
                .build();
        httpPost.setConfig(requestConfig);
        return httpClient.execute(httpPost);
    }

    public static HttpResponse httpClientPostSSLUrl(Map<String, String> headers, String url, String data,String certPath,String certPassword) throws  Exception{
    	// Trust own CA and all self-signed certs
        SSLContext sslcontext = SSLContexts.custom()
                .loadTrustMaterial(new File(certPath), certPassword.toCharArray(),
                        new TrustSelfSignedStrategy())
                .build();
        // Allow TLSv1 protocol only
        SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
                sslcontext,
                new String[] { "TLSv1" },
                null,
                SSLConnectionSocketFactory.getDefaultHostnameVerifier());
        CloseableHttpClient httpclient = HttpClients.custom()
                .setSSLSocketFactory(sslsf)
                .build();
        
        HttpPost httpPost = new HttpPost(url);
        for(Map.Entry<String, String> entry: headers.entrySet()) {
            httpPost.addHeader(entry.getKey(), entry.getValue());
        }
        httpPost.setEntity(new StringEntity(data));
        RequestConfig requestConfig = RequestConfig.custom()
                //设置连接超时时间
                .setConnectTimeout(30000)
                        //设置从connect Manager获取Connection 超时时间
                .setConnectionRequestTimeout(30000)
                        //请求获取数据的超时时间
                .setSocketTimeout(30000)
                .build();
        httpPost.setConfig(requestConfig);
        return httpclient.execute(httpPost);
    }
    
    public static HttpResponse httpClientPostUrl(Map<String, String> headers, String url, List<NameValuePair> data) throws  Exception{
        HttpClientBuilder hcBuilder = HttpClients.custom();
        hcBuilder.setRedirectStrategy(new LaxRedirectStrategy());
        //CloseableHttpClient httpClient = HttpClients.createDefault();
        CloseableHttpClient httpClient = hcBuilder.build();
        //httpClient.getParams().setParameter("http.protocol.allow-circular-redirects", true);
        HttpPost httpPost = new HttpPost(url);
        for(Map.Entry<String, String> entry: headers.entrySet()) {
            httpPost.addHeader(entry.getKey(), entry.getValue());
        }
        httpPost.setEntity(new UrlEncodedFormEntity(data));
        RequestConfig requestConfig = RequestConfig.custom()
                //设置连接超时时间
                .setConnectTimeout(30000)
                        //设置从connect Manager获取Connection 超时时间
                .setConnectionRequestTimeout(30000)
                        //请求获取数据的超时时间
                .setSocketTimeout(30000)
                .build();
        httpPost.setConfig(requestConfig);
        return httpClient.execute(httpPost);
    }

    public static JsonNode toJson(String resp) throws Exception {
        return new ObjectMapper().readTree(resp);
    }

    public static JsonNode toJson(HttpResponse resp) throws Exception {
        HttpEntity entity = resp.getEntity();
        if(entity != null) {
            String strEntity = EntityUtils.toString(entity);
            if( strEntity != null) {
                return new ObjectMapper().readTree(strEntity);
            }
            else {
                throw new Exception("HTTP内容字符串为空");
            }
        }
        else {
            throw new Exception("HTTP请求返回内容为空");
        }
    }
}
