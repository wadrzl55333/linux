package com.whitehole.isv.spring.boot.event.esb.entity;

/**
 * Created by zijian on 10/10/16.
 */
public class APIMAPIResource {
    private String provider;
    private String version;
    private String description;
    private String status;
    private String name;
    private String context;
    private String id;

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    //    {
//        "provider": "admin",
//            "version": "1.0.0",
//            "description": "This API provide Account Status Validation.",
//            "status": "PUBLISHED",
//            "name": "AccountVal",
//            "context": "/account/1.0.0",
//            "id": "2e81f147-c8a8-4f68-b4f0-69e0e7510b01"
//    },
}
