package com.whitehole.isv.spring.boot.event.esb.schedule;

/**
 * Created by zijian on 12/16/16.
 */


import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.whitehole.isv.spring.boot.event.esb.service.ApiServiceForDatabase;
import com.whitehole.isv.spring.boot.event.esb.service.NginxConfigurationService;
import com.whitehole.isv.spring.boot.event.esb.service.StandardETCDService;
import com.whitehole.isv.spring.boot.event.esb.util.NginxOperationUtil;
import com.whitehole.isv.spring.boot.event.esb.entity.*;

import javax.sql.DataSource;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider.API_MANAGER_OUTENDPOINT;


@Component
public class ScheduledTasks {
	
	@Value("${nginx.config.file.path}")
    private String path;
	
    @Autowired
    private ApiServiceForDatabase apiServiceForDatabase;
    
    @Autowired
    private NginxConfigurationService nginxConfigurationService;
    
    @Autowired
    private StandardETCDService standardETCDService;
	
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

//    @Resource(name = "apimDataSource")
//    private DataSource apimDataSource;
//    @Resource(name = "portalDataSource")
//    private DataSource portalDataSource;

    private static Logger logger = LogManager.getLogger(ScheduledTasks.class);

    @Scheduled(fixedRate = 5000)
    public void reportCurrentTime() {
//        System.out.println("The time is now " + dateFormat.format(new Date()));
        List<LimitIp> limitIpList = apiServiceForDatabase.getLimitIp();
        for(LimitIp limitIp:limitIpList){
//        	limitIp.setIsAllow(nginxConfigurationService.addLocationUrl(limitIp.getUrl(), limitIp.getIp()));
        	logger.info("The time is now " + dateFormat.format(new Date()));
        	logger.info(limitIp.getUrl() + limitIp.getIp() + " is handling");
        	if(nginxConfigurationService.addLocationUrl(limitIp.getUrl(),API_MANAGER_OUTENDPOINT+limitIp.getUrl(),limitIp.getIp())){
        		apiServiceForDatabase.changeLimitIpStatus(limitIp.getId());
        		standardETCDService.initialize();
        		standardETCDService.sendAndGet("aaa",standardETCDService.read(path));
        		NginxOperationUtil.reloadNginx();
        	}
        }
        
    }
}